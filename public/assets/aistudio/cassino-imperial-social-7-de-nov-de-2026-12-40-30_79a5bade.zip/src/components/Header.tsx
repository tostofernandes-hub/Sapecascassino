import React from 'react';
import { GameId } from '../types/casino';
import { Volume2, VolumeX, Sparkles, RefreshCw, Gift } from 'lucide-react';

interface HeaderProps {
  activeGame: GameId;
  onNavigate: (game: GameId) => void;
  balance: number;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenSocialModal: () => void;
  onRefillChips: () => void;
  onOpenDailyBonus: () => void;
  hasDailyBonusAvailable: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeGame,
  onNavigate,
  balance,
  isMuted,
  onToggleMute,
  onOpenSocialModal,
  onRefillChips,
  onOpenDailyBonus,
  hasDailyBonusAvailable
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#080d0a]/90 backdrop-blur-md border-b border-amber-500/20 px-4 sm:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Wordmark */}
        <button
          onClick={() => onNavigate('lobby')}
          className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/20 border border-amber-300">
            <span className="text-slate-950 font-cinzel font-black text-lg">♠</span>
          </div>
          <div>
            <span className="font-cinzel text-lg sm:text-xl font-bold tracking-wider text-amber-300 group-hover:text-amber-200 transition-colors block leading-tight">
              IMPERIAL
            </span>
            <span className="text-[10px] uppercase tracking-widest text-emerald-400 font-semibold block leading-none">
              Cassino Social
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            onClick={() => onNavigate('lobby')}
            className={`whitespace-nowrap transition-colors hover:text-amber-300 cursor-pointer ${
              activeGame === 'lobby' ? 'text-amber-400 font-semibold' : 'text-slate-300'
            }`}
          >
            Lobby de Jogos
          </button>
          <button
            onClick={() => onNavigate('records')}
            className={`whitespace-nowrap transition-colors hover:text-amber-300 cursor-pointer ${
              activeGame === 'records' ? 'text-amber-400 font-semibold' : 'text-slate-300'
            }`}
          >
            Placar de Recordes
          </button>
          <button
            onClick={onOpenSocialModal}
            className="whitespace-nowrap text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
          >
            Aviso de Cassino Social
          </button>
        </nav>

        {/* Zone 3: Actions & Balance */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Fictional Chip Balance */}
          <div className="flex items-center gap-2 bg-slate-900/90 border border-amber-500/30 px-3 py-1.5 rounded-lg shadow-inner">
            <span className="text-base" role="img" aria-label="Fichas">🪙</span>
            <div className="flex flex-col text-right">
              <span className="text-[9px] uppercase tracking-wider text-slate-400 font-semibold leading-none">
                Fichas
              </span>
              <span className="font-mono text-sm sm:text-base font-bold text-amber-300 tabular-nums leading-tight">
                {balance.toLocaleString('pt-BR')}
              </span>
            </div>
          </div>

          {/* Quick Bonus / Refill Button if balance is low */}
          {balance < 100 && (
            <button
              onClick={onRefillChips}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md animate-pulse cursor-pointer transition-colors whitespace-nowrap"
              title="Receber +1.000 fichas bônus grátis"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">+1.000 Grátis</span>
            </button>
          )}

          {/* Daily Bonus Button */}
          <button
            onClick={onOpenDailyBonus}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold shadow transition-all cursor-pointer whitespace-nowrap ${
              hasDailyBonusAvailable
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 border-amber-300 ring-2 ring-amber-400 animate-pulse'
                : 'bg-slate-900/90 text-amber-300 border-amber-500/30 hover:bg-slate-800'
            }`}
            title="Bônus Diário de Fichas"
          >
            <Gift className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{hasDailyBonusAvailable ? 'Bônus Diário!' : 'Bônus'}</span>
          </button>

          {/* Sound Mute Toggle */}
          <button
            onClick={onToggleMute}
            aria-label={isMuted ? 'Ativar som' : 'Desativar som'}
            className="w-9 h-9 rounded-lg bg-slate-900 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-300 flex items-center justify-center transition-colors cursor-pointer"
            title={isMuted ? 'Som Desativado (Clique para ativar)' : 'Som Ativado (Clique para desativar)'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>
    </header>
  );
};
