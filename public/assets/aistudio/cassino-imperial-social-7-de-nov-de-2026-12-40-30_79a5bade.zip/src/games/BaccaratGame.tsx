import React, { useState } from 'react';
import { Card } from '../types/casino';
import { createDeck, shuffleDeck, calculateBaccaratScore } from '../utils/cards';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { PlayingCard } from '../components/PlayingCard';
import { ChipSelector } from '../components/ChipSelector';
import { HowToPlayModal } from '../components/HowToPlayModal';
import { ArrowLeft, Play, RotateCcw, HelpCircle } from 'lucide-react';

interface BaccaratGameProps {
  balance: number;
  onUpdateBalance: (delta: number, isWin: boolean, gameId: 'baccarat', betAmount?: number) => void;
  onBackToLobby: () => void;
}

type BetTarget = 'PLAYER' | 'BANKER' | 'TIE';
type GamePhase = 'BETTING' | 'DEALING' | 'ENDED';

export const BaccaratGame: React.FC<BaccaratGameProps> = ({
  balance,
  onUpdateBalance,
  onBackToLobby
}) => {
  const [bet, setBet] = useState<number>(50);
  const [betTarget, setBetTarget] = useState<BetTarget>('PLAYER');
  const [phase, setPhase] = useState<GamePhase>('BETTING');
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [bankerHand, setBankerHand] = useState<Card[]>([]);
  const [resultText, setResultText] = useState<string>('');
  const [resultWinner, setResultWinner] = useState<BetTarget | null>(null);
  const [roadMap, setRoadMap] = useState<('P' | 'B' | 'T')[]>(['B', 'P', 'B', 'B', 'T', 'P']);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  const handleStart = () => {
    if (bet <= 0 || bet > balance) return;

    soundManager.playShuffle();
    onUpdateBalance(-bet, false, 'baccarat');
    setPhase('DEALING');
    setResultText('');
    setResultWinner(null);

    const deck = shuffleDeck(createDeck());

    // Initial 2 cards each
    const p1 = deck.pop()!;
    const b1 = deck.pop()!;
    const p2 = deck.pop()!;
    const b2 = deck.pop()!;

    let currentP = [p1, p2];
    let currentB = [b1, b2];

    setPlayerHand(currentP);
    setBankerHand(currentB);
    soundManager.playCardDeal();

    setTimeout(() => {
      let pScore = calculateBaccaratScore(currentP);
      let bScore = calculateBaccaratScore(currentB);

      // Check for Natural (8 or 9)
      const isNatural = pScore >= 8 || bScore >= 8;

      if (!isNatural) {
        let playerThirdCard: Card | null = null;

        // Player Rule: draws if score <= 5
        if (pScore <= 5) {
          playerThirdCard = deck.pop()!;
          currentP = [...currentP, playerThirdCard];
          pScore = calculateBaccaratScore(currentP);
          soundManager.playCardDeal();
        }

        // Banker Rule
        if (!playerThirdCard) {
          // Player stood (had 6 or 7) -> Banker draws if score <= 5
          if (bScore <= 5) {
            const b3 = deck.pop()!;
            currentB = [...currentB, b3];
            bScore = calculateBaccaratScore(currentB);
            soundManager.playCardDeal();
          }
        } else {
          // Standard Baccarat Tableau rule based on Player's 3rd card
          const p3Val = playerThirdCard.value >= 10 ? 0 : playerThirdCard.value;
          let bankerDraws = false;

          if (bScore <= 2) {
            bankerDraws = true;
          } else if (bScore === 3 && p3Val !== 8) {
            bankerDraws = true;
          } else if (bScore === 4 && [2, 3, 4, 5, 6, 7].includes(p3Val)) {
            bankerDraws = true;
          } else if (bScore === 5 && [4, 5, 6, 7].includes(p3Val)) {
            bankerDraws = true;
          } else if (bScore === 6 && [6, 7].includes(p3Val)) {
            bankerDraws = true;
          }

          if (bankerDraws) {
            const b3 = deck.pop()!;
            currentB = [...currentB, b3];
            bScore = calculateBaccaratScore(currentB);
            soundManager.playCardDeal();
          }
        }
      }

      setPlayerHand(currentP);
      setBankerHand(currentB);

      // Determine Winner
      let winner: BetTarget;
      if (pScore > bScore) {
        winner = 'PLAYER';
      } else if (bScore > pScore) {
        winner = 'BANKER';
      } else {
        winner = 'TIE';
      }

      setResultWinner(winner);
      setRoadMap((prev) => [...prev.slice(-14), winner === 'PLAYER' ? 'P' : winner === 'BANKER' ? 'B' : 'T']);

      const winnerLabel =
        winner === 'PLAYER'
          ? `Jogador Vence (${pScore} vs ${bScore})`
          : winner === 'BANKER'
          ? `Banca Vence (${bScore} vs ${pScore})`
          : `Empate (${pScore} a ${bScore})`;

      // Calculate payout based on user bet
      if (betTarget === winner) {
        let payout = 0;
        if (winner === 'PLAYER') {
          payout = bet * 2; // 1:1
        } else if (winner === 'BANKER') {
          payout = Math.floor(bet + bet * 0.95); // 0.95:1
        } else {
          payout = bet * 9; // 8:1 (return bet + 8*bet)
        }

        soundManager.playWin();
        fireConfetti(2200);
        onUpdateBalance(payout, true, 'baccarat', bet);
        setResultText(`Vitória! ${winnerLabel}. Você recebeu ${payout} fichas!`);
      } else if (winner === 'TIE') {
        // In standard baccarat, bets on Player or Banker are pushed (refunded) if Tie occurs!
        soundManager.playLoss();
        onUpdateBalance(bet, false, 'baccarat');
        setResultText(`Empate! Fichas devolvidas integralmente.`);
      } else {
        soundManager.playLoss();
        setResultText(`${winnerLabel}. Aposta perdida.`);
      }

      setPhase('ENDED');
    }, 1200);
  };

  const pScore = calculateBaccaratScore(playerHand);
  const bScore = calculateBaccaratScore(bankerHand);

  return (
    <div className="space-y-3 max-w-4xl mx-auto animate-fade-in">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Voltar ao Lobby</span>
        </button>

        {/* Road Map / Bead Plate History */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-slate-400 hidden sm:inline">Histórico:</span>
            <div className="flex items-center gap-1">
              {roadMap.map((res, i) => (
                <span
                  key={i}
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black text-white ${
                    res === 'P'
                      ? 'bg-blue-600'
                      : res === 'B'
                      ? 'bg-red-600'
                      : 'bg-emerald-600'
                  }`}
                  title={res === 'P' ? 'Jogador' : res === 'B' ? 'Banca' : 'Empate'}
                >
                  {res}
                </span>
              ))}
            </div>
          </div>

          <button
            onClick={() => setShowHowToPlay(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Como Jogar</span>
          </button>
        </div>
      </div>

      {/* Baccarat Table Felt */}
      <div className="casino-felt casino-wood-border rounded-2xl p-3 sm:p-4 min-h-[220px] sm:min-h-[250px] flex flex-col justify-between shadow-xl relative">
        {/* Table Watermark */}
        <div className="text-center">
          <span className="text-[11px] text-amber-400/80 font-cinzel tracking-widest uppercase">
            Bacarate Imperial · Punto Banco
          </span>
        </div>

        {/* Both Hands Side by Side */}
        <div className="grid grid-cols-2 gap-3 sm:gap-6 my-2">
          {/* Player Hand Zone */}
          <div
            className={`p-2.5 sm:p-3 rounded-xl border transition-all ${
              resultWinner === 'PLAYER'
                ? 'bg-blue-950/40 border-blue-400 ring-2 ring-blue-400/60 shadow-md shadow-blue-500/20'
                : 'bg-slate-900/40 border-slate-700/60'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-cinzel font-bold text-blue-400 tracking-wider uppercase">
                Jogador (Player)
              </span>
              {playerHand.length > 0 && (
                <span className="bg-blue-950 border border-blue-500/40 px-1.5 py-0.2 rounded text-[11px] font-mono font-bold text-blue-300">
                  Total: {pScore}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 justify-center min-h-[90px] sm:min-h-[100px]">
              {playerHand.length === 0 ? (
                <div className="w-14 h-20 rounded-lg border-2 border-dashed border-blue-400/20 flex items-center justify-center text-[10px] text-blue-400/40">
                  Jogador
                </div>
              ) : (
                playerHand.map((card, idx) => (
                  <PlayingCard key={card.id || idx} card={card} size="sm" />
                ))
              )}
            </div>
          </div>

          {/* Banker Hand Zone */}
          <div
            className={`p-2.5 sm:p-3 rounded-xl border transition-all ${
              resultWinner === 'BANKER'
                ? 'bg-red-950/40 border-red-400 ring-2 ring-red-400/60 shadow-md shadow-red-500/20'
                : 'bg-slate-900/40 border-slate-700/60'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-cinzel font-bold text-red-400 tracking-wider uppercase">
                Banca (Banker)
              </span>
              {bankerHand.length > 0 && (
                <span className="bg-red-950 border border-red-500/40 px-1.5 py-0.2 rounded text-[11px] font-mono font-bold text-red-300">
                  Total: {bScore}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 justify-center min-h-[90px] sm:min-h-[100px]">
              {bankerHand.length === 0 ? (
                <div className="w-14 h-20 rounded-lg border-2 border-dashed border-red-400/20 flex items-center justify-center text-[10px] text-red-400/40">
                  Banca
                </div>
              ) : (
                bankerHand.map((card, idx) => (
                  <PlayingCard key={card.id || idx} card={card} size="sm" />
                ))
              )}
            </div>
          </div>
        </div>

        {/* Center Result Message */}
        {resultText ? (
          <div className="text-center animate-bounce py-1">
            <div
              className={`inline-block px-4 py-1.5 rounded-lg font-cinzel font-bold text-xs sm:text-sm border shadow-lg ${
                betTarget === resultWinner
                  ? 'bg-amber-500 text-slate-950 border-amber-300'
                  : 'bg-slate-900 border-slate-700 text-slate-200'
              }`}
            >
              {resultText}
            </div>
          </div>
        ) : (
          <div className="text-center py-1 text-[11px] text-slate-400">
            Aposte no Jogador (1:1), Empate (8:1) ou Banca (0,95:1)
          </div>
        )}
      </div>

      {/* Betting Control Bar: Target selection + ChipSelector + Play Action */}
      <div className="bg-[#09150f] border border-amber-500/30 rounded-xl p-2.5 sm:p-3 shadow-xl space-y-2.5">
        {/* Betting Targets */}
        <div className="grid grid-cols-3 gap-2">
          {/* Bet Player */}
          <button
            type="button"
            disabled={phase === 'DEALING'}
            onClick={() => {
              soundManager.playClick();
              setBetTarget('PLAYER');
            }}
            className={`py-1.5 px-2 rounded-lg border flex flex-col items-center justify-center transition-all cursor-pointer ${
              betTarget === 'PLAYER'
                ? 'bg-blue-600/30 border-blue-400 ring-2 ring-blue-400 text-white font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span className="text-xs">Jogador</span>
            <span className="text-[10px] text-blue-400 font-mono">1:1</span>
          </button>

          {/* Bet Tie */}
          <button
            type="button"
            disabled={phase === 'DEALING'}
            onClick={() => {
              soundManager.playClick();
              setBetTarget('TIE');
            }}
            className={`py-1.5 px-2 rounded-lg border flex flex-col items-center justify-center transition-all cursor-pointer ${
              betTarget === 'TIE'
                ? 'bg-emerald-600/30 border-emerald-400 ring-2 ring-emerald-400 text-white font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span className="text-xs">Empate (Tie)</span>
            <span className="text-[10px] text-emerald-400 font-mono">8:1</span>
          </button>

          {/* Bet Banker */}
          <button
            type="button"
            disabled={phase === 'DEALING'}
            onClick={() => {
              soundManager.playClick();
              setBetTarget('BANKER');
            }}
            className={`py-1.5 px-2 rounded-lg border flex flex-col items-center justify-center transition-all cursor-pointer ${
              betTarget === 'BANKER'
                ? 'bg-red-600/30 border-red-400 ring-2 ring-red-400 text-white font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span className="text-xs">Banca</span>
            <span className="text-[10px] text-red-400 font-mono">0,95:1</span>
          </button>
        </div>

        {/* Chips Selector and Action Button Row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1">
          <div className="flex-1">
            <ChipSelector
              currentBet={bet}
              balance={balance}
              onBetChange={setBet}
              disabled={phase === 'DEALING'}
            />
          </div>

          <button
            type="button"
            disabled={phase === 'DEALING' || bet <= 0 || bet > balance}
            onClick={handleStart}
            className="sm:w-56 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            {phase === 'ENDED' ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{phase === 'DEALING' ? 'Distribuindo...' : phase === 'ENDED' ? 'Nova Rodada' : 'Confirmar e Jogar'}</span>
          </button>
        </div>
      </div>

      {/* Rules Modal */}
      <HowToPlayModal
        isOpen={showHowToPlay}
        onClose={() => setShowHowToPlay(false)}
        gameId="baccarat"
      />
    </div>
  );
};
