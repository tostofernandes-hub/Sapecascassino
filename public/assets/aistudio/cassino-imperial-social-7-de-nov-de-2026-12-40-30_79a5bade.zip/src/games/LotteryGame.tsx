import React, { useState } from 'react';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { HowToPlayModal } from '../components/HowToPlayModal';
import { ArrowLeft, Play, Sparkles, Trash2, Dices, RotateCcw, HelpCircle } from 'lucide-react';

interface LotteryGameProps {
  balance: number;
  onUpdateBalance: (delta: number, isWin: boolean, gameId: 'lottery', betAmount?: number) => void;
  onBackToLobby: () => void;
}

// Cost multiplier by number of picks (6 to 15 numbers)
const COST_FACTORS: Record<number, number> = {
  6: 1,
  7: 7,
  8: 28,
  9: 84,
  10: 210,
  11: 462,
  12: 924,
  13: 1716,
  14: 3003,
  15: 5005
};

export const LotteryGame: React.FC<LotteryGameProps> = ({
  balance,
  onUpdateBalance,
  onBackToLobby
}) => {
  const [selectedNumbers, setSelectedNumbers] = useState<Set<number>>(new Set([7, 14, 21, 33, 42, 58]));
  const [baseBet, setBaseBet] = useState<number>(10);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [drawnNumbers, setDrawnNumbers] = useState<number[]>([]);
  const [hitsCount, setHitsCount] = useState<number | null>(null);
  const [resultMessage, setResultMessage] = useState<string>('');
  const [winAmount, setWinAmount] = useState<number>(0);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  const pickCount = selectedNumbers.size;
  const factor = COST_FACTORS[pickCount] || 1;
  const totalBet = baseBet * factor;

  const toggleNumber = (num: number) => {
    if (isDrawing) return;
    soundManager.playClick();
    setSelectedNumbers((prev) => {
      const next = new Set(prev);
      if (next.has(num)) {
        next.delete(num);
      } else {
        if (next.size >= 15) return prev; // Maximum 15 numbers
        next.add(num);
      }
      return next;
    });
  };

  const handleClear = () => {
    if (isDrawing) return;
    soundManager.playClick();
    setSelectedNumbers(new Set());
    setHitsCount(null);
    setResultMessage('');
    setDrawnNumbers([]);
  };

  const handleSurpresinha = () => {
    if (isDrawing) return;
    soundManager.playClick();
    const randomSet = new Set<number>();
    while (randomSet.size < 6) {
      randomSet.add(Math.floor(Math.random() * 60) + 1);
    }
    setSelectedNumbers(randomSet);
    setHitsCount(null);
    setResultMessage('');
    setDrawnNumbers([]);
  };

  const handleDraw = () => {
    if (isDrawing || pickCount < 6 || pickCount > 15 || totalBet > balance) return;

    setIsDrawing(true);
    setHitsCount(null);
    setResultMessage('');
    setDrawnNumbers([]);
    setWinAmount(0);

    // Deduct cost
    onUpdateBalance(-totalBet, false, 'lottery');

    // Pick 6 unique winning numbers from 1 to 60
    const winningSet = new Set<number>();
    while (winningSet.size < 6) {
      winningSet.add(Math.floor(Math.random() * 60) + 1);
    }
    const finalNumbers = Array.from(winningSet).sort((a, b) => a - b);

    // Reveal balls sequentially (1 ball every 600ms)
    let revealed: number[] = [];
    finalNumbers.forEach((ball, idx) => {
      setTimeout(() => {
        revealed = [...revealed, ball];
        setDrawnNumbers(revealed);
        soundManager.playRouletteTick(1000 + idx * 100);

        // When last ball is revealed
        if (idx === 5) {
          setTimeout(() => {
            setIsDrawing(false);

            // Count hits
            let hits = 0;
            for (const n of finalNumbers) {
              if (selectedNumbers.has(n)) {
                hits++;
              }
            }

            setHitsCount(hits);

            if (hits === 6) {
              // SENA! Mega Jackpot!
              const prize = baseBet * 50000;
              setWinAmount(prize);
              setResultMessage(`SENA HISTÓRICA! 6 ACERTOS! Você ganhou ${prize.toLocaleString('pt-BR')} fichas!`);
              soundManager.playJackpot();
              fireConfetti(4000);
              onUpdateBalance(prize, true, 'lottery', totalBet);
            } else if (hits === 5) {
              // QUINA!
              const prize = baseBet * 1500;
              setWinAmount(prize);
              setResultMessage(`QUINA! 5 ACERTOS! Você ganhou ${prize.toLocaleString('pt-BR')} fichas!`);
              soundManager.playWin();
              fireConfetti(2500);
              onUpdateBalance(prize, true, 'lottery', totalBet);
            } else if (hits === 4) {
              // QUADRA!
              const prize = baseBet * 50;
              setWinAmount(prize);
              setResultMessage(`QUADRA! 4 ACERTOS! Você ganhou ${prize.toLocaleString('pt-BR')} fichas!`);
              soundManager.playWin();
              fireConfetti(1500);
              onUpdateBalance(prize, true, 'lottery', totalBet);
            } else {
              soundManager.playLoss();
              setResultMessage(`Você acertou ${hits} ${hits === 1 ? 'número' : 'números'}. Faixa mínima de prêmio é 4 acertos (Quadra).`);
            }
          }, 800);
        }
      }, (idx + 1) * 600);
    });
  };

  return (
    <div className="space-y-2.5 max-w-4xl mx-auto animate-fade-in">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Voltar ao Lobby</span>
        </button>

        <button
          onClick={() => setShowHowToPlay(true)}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
          <span>Como Jogar</span>
        </button>
      </div>

      {/* Live Ball Drawing Sphere Container */}
      <div className="casino-felt border border-amber-500/30 rounded-xl p-2.5 sm:p-3 shadow-xl text-center space-y-2">
        <div className="flex items-center justify-between px-2">
          <span className="text-[11px] font-cinzel font-bold text-amber-300 uppercase tracking-widest block">
            Globo do Sorteio das 6 Dezenas
          </span>
          {/* Quick prize mini summary */}
          <div className="hidden sm:flex items-center gap-3 text-[10px] text-slate-300 font-mono">
            <span>Sena: <strong className="text-amber-400">50.000x</strong></span>
            <span>Quina: <strong className="text-emerald-400">1.500x</strong></span>
            <span>Quadra: <strong className="text-blue-400">50x</strong></span>
          </div>
        </div>

        {/* 6 Drawn Balls */}
        <div className="flex items-center justify-center gap-2 sm:gap-3 min-h-[48px] flex-wrap">
          {Array.from({ length: 6 }).map((_, idx) => {
            const ball = drawnNumbers[idx];
            const isMatch = ball !== undefined && selectedNumbers.has(ball);
            return (
              <div
                key={idx}
                className={`w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center font-cinzel font-bold text-sm sm:text-base shadow-lg transition-all duration-300 ${
                  ball !== undefined
                    ? isMatch
                      ? 'bg-amber-400 text-slate-950 ring-2 ring-white animate-bounce scale-110 font-black'
                      : 'bg-emerald-600 text-white border border-emerald-300'
                    : 'bg-slate-900/60 border border-dashed border-amber-500/30 text-amber-500/30 text-xs'
                }`}
              >
                {ball !== undefined ? ball : '?'}
              </div>
            );
          })}
        </div>

        {/* Result Message */}
        {resultMessage && (
          <div className="pt-0.5 animate-bounce">
            <div
              className={`inline-block px-4 py-1 rounded-lg font-cinzel font-bold text-xs sm:text-sm border shadow-lg ${
                winAmount > 0
                  ? 'bg-amber-500 text-slate-950 border-amber-300'
                  : 'bg-slate-900 border-slate-700 text-slate-300'
              }`}
            >
              {resultMessage}
            </div>
          </div>
        )}
      </div>

      {/* Interactive 1 to 60 Numbers Card Grid */}
      <div className="bg-[#09150f] border border-amber-500/30 rounded-xl p-2.5 sm:p-3.5 shadow-xl space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div>
            <span className="text-xs font-cinzel font-bold text-amber-300 uppercase tracking-wider block">
              Volante da Loteria (6 a 15 dezenas)
            </span>
            <span className="text-[11px] text-slate-400">
              Selecionados: <strong className="text-amber-400 font-bold">{pickCount}</strong> de 15 máx.
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={isDrawing}
              onClick={handleSurpresinha}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-amber-300 border border-amber-500/30 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Dices className="w-3.5 h-3.5" />
              <span>Surpresinha (6)</span>
            </button>

            <button
              type="button"
              disabled={isDrawing || pickCount === 0}
              onClick={handleClear}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar</span>
            </button>
          </div>
        </div>

        {/* 60 Numbers Grid (10 columns) */}
        <div className="grid grid-cols-6 sm:grid-cols-10 gap-1 sm:gap-1.5">
          {Array.from({ length: 60 }, (_, i) => i + 1).map((num) => {
            const isSelected = selectedNumbers.has(num);
            const isHit = drawnNumbers.includes(num);
            return (
              <button
                key={num}
                type="button"
                disabled={isDrawing}
                onClick={() => toggleNumber(num)}
                className={`h-7 sm:h-8 rounded font-bold text-xs transition-all select-none flex items-center justify-center cursor-pointer ${
                  isSelected
                    ? isHit
                      ? 'bg-amber-400 text-slate-950 ring-2 ring-white scale-105 font-black'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                }`}
              >
                {num}
              </button>
            );
          })}
        </div>

        {/* Bet Calculation & Draw Action */}
        <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">Aposta Base:</span>
            <div className="flex items-center gap-1">
              {[5, 10, 25, 50].map((v) => (
                <button
                  key={v}
                  type="button"
                  disabled={isDrawing}
                  onClick={() => {
                    soundManager.playClick();
                    setBaseBet(v);
                  }}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold transition-colors cursor-pointer ${
                    baseBet === v
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {v}
                </button>
              ))}
            </div>

            <span className="text-[11px] text-slate-400 font-mono ml-2">
              Total: <strong className="text-amber-300 font-bold">{totalBet}</strong> fichas
            </span>
          </div>

          <button
            type="button"
            disabled={isDrawing || pickCount < 6 || pickCount > 15 || totalBet > balance}
            onClick={handleDraw}
            className="sm:w-auto px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white font-cinzel font-bold text-xs sm:text-sm shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            {drawnNumbers.length > 0 && !isDrawing ? (
              <RotateCcw className="w-4 h-4" />
            ) : (
              <Play className="w-4 h-4 fill-current" />
            )}
            <span>
              {isDrawing
                ? 'Sorteando...'
                : drawnNumbers.length > 0
                ? 'Novo Sorteio'
                : `Apostar e Sortear (${totalBet} Fichas)`}
            </span>
          </button>
        </div>
      </div>

      {/* Rules Modal */}
      <HowToPlayModal
        isOpen={showHowToPlay}
        onClose={() => setShowHowToPlay(false)}
        gameId="lottery"
      />
    </div>
  );
};
