import React from 'react';
import { Card } from '../types/casino';
import { getSuitColor, getSuitSymbol } from '../utils/cards';

interface PlayingCardProps {
  card?: Card;
  hidden?: boolean;
  held?: boolean;
  onToggleHold?: () => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const PlayingCard: React.FC<PlayingCardProps> = ({
  card,
  hidden = false,
  held = false,
  onToggleHold,
  className = '',
  size = 'md'
}) => {
  const sizeClasses = {
    sm: 'w-14 h-20 text-xs',
    md: 'w-20 h-28 sm:w-24 sm:h-36 text-sm sm:text-base',
    lg: 'w-24 h-36 sm:w-28 sm:h-44 text-base sm:text-lg'
  }[size];

  if (hidden || !card) {
    return (
      <div
        className={`relative ${sizeClasses} rounded-lg select-none shadow-xl border-2 border-amber-600/60 bg-gradient-to-br from-red-950 via-red-900 to-amber-950 flex items-center justify-center overflow-hidden transition-all duration-300 ${className}`}
      >
        {/* Ornate back of card pattern */}
        <div className="absolute inset-1 border border-amber-500/40 rounded flex items-center justify-center">
          <div className="w-full h-full opacity-30 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:8px_8px]" />
          <div className="absolute w-8 h-8 rounded-full border border-amber-400/60 flex items-center justify-center text-amber-300 font-cinzel font-bold text-xs">
            ♠
          </div>
        </div>
      </div>
    );
  }

  const isRed = card.suit === 'hearts' || card.suit === 'diamonds';
  const suitSymbol = getSuitSymbol(card.suit);

  return (
    <div
      onClick={onToggleHold}
      className={`relative ${sizeClasses} rounded-lg select-none bg-white text-slate-900 shadow-xl border border-slate-300 flex flex-col justify-between p-1.5 sm:p-2.5 transition-transform duration-200 ${
        onToggleHold ? 'cursor-pointer hover:-translate-y-1' : ''
      } ${held ? 'ring-4 ring-amber-400 -translate-y-2' : ''} ${className}`}
    >
      {/* Top-left corner */}
      <div className={`flex flex-col items-center leading-none ${isRed ? 'text-red-600' : 'text-slate-900'}`}>
        <span className="font-bold font-sans tracking-tight">{card.label}</span>
        <span className="text-xs sm:text-sm">{suitSymbol}</span>
      </div>

      {/* Center artwork */}
      <div className={`self-center flex flex-col items-center ${isRed ? 'text-red-600' : 'text-slate-900'}`}>
        <span className="text-xl sm:text-3xl filter drop-shadow-sm">{suitSymbol}</span>
        {card.value >= 11 && (
          <span className="text-[10px] sm:text-xs font-cinzel font-semibold opacity-75 mt-0.5">
            {card.label === 'J' ? 'VALETE' : card.label === 'Q' ? 'DAMA' : 'REI'}
          </span>
        )}
      </div>

      {/* Bottom-right corner (inverted) */}
      <div className={`flex flex-col items-center leading-none rotate-180 ${isRed ? 'text-red-600' : 'text-slate-900'}`}>
        <span className="font-bold font-sans tracking-tight">{card.label}</span>
        <span className="text-xs sm:text-sm">{suitSymbol}</span>
      </div>

      {/* Held label overlay for video poker */}
      {held && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500 text-slate-950 text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded shadow-md tracking-wider uppercase">
          Manter
        </div>
      )}
    </div>
  );
};
