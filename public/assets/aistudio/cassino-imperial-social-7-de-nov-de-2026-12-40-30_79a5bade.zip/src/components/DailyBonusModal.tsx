import React from 'react';
import { Gift, X, Sparkles, Check, Calendar } from 'lucide-react';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';

interface DailyBonusModalProps {
  isOpen: boolean;
  onClose: () => void;
  streak: number;
  bonusAmount: number;
  onClaim: () => void;
  alreadyClaimed: boolean;
}

export const DailyBonusModal: React.FC<DailyBonusModalProps> = ({
  isOpen,
  onClose,
  streak,
  bonusAmount,
  onClaim,
  alreadyClaimed
}) => {
  if (!isOpen) return null;

  const handleClaim = () => {
    soundManager.playJackpot();
    fireConfetti(3000);
    onClaim();
    onClose();
  };

  const streakDays = [
    { day: 1, amount: 500 },
    { day: 2, amount: 750 },
    { day: 3, amount: 1000 },
    { day: 4, amount: 1250 },
    { day: 5, amount: 1500 },
    { day: 6, amount: 1750 },
    { day: 7, amount: 2500 }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0e1813] border-2 border-amber-500/50 rounded-2xl max-w-md w-full p-6 shadow-2xl relative text-center">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800/60 transition-colors cursor-pointer"
          aria-label="Fechar"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Gift Icon Header */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 mx-auto flex items-center justify-center text-slate-950 shadow-xl shadow-amber-500/30 mb-4 border border-amber-300">
          <Gift className="w-8 h-8" />
        </div>

        <h3 className="font-cinzel text-2xl font-bold text-white">
          Bônus Diário de Fichas
        </h3>
        
        <p className="text-xs text-slate-300 mt-1">
          {alreadyClaimed
            ? 'Você já resgatou sua recompensa de hoje! Retorne amanhã para continuar sua sequência.'
            : 'Bem-vindo de volta! Resgate suas fichas diárias gratuitas para continuar jogando.'}
        </p>

        {/* Big Chip Display */}
        <div className="my-5 py-4 bg-slate-950/80 rounded-xl border border-amber-500/40 flex flex-col items-center justify-center">
          <span className="text-xs font-semibold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" /> Recompensa de Hoje
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl">🪙</span>
            <span className="font-mono text-3xl sm:text-4xl font-black text-gold-gradient tabular-nums">
              +{bonusAmount.toLocaleString('pt-BR')}
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5">
            Fichas 100% gratuitas e fictícias
          </span>
        </div>

        {/* 7-Day Streak Timeline */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-amber-400" /> Sequência de Visitas:
            </span>
            <span className="font-bold text-amber-300 font-mono">
              Dia {Math.min(7, streak || 1)} de 7
            </span>
          </div>

          <div className="grid grid-cols-7 gap-1.5">
            {streakDays.map((item) => {
              const currentActive = (streak || 1) === item.day;
              const completed = (streak || 1) > item.day || (alreadyClaimed && currentActive);
              return (
                <div
                  key={item.day}
                  className={`p-1.5 rounded-lg border text-center transition-all ${
                    currentActive
                      ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400'
                      : completed
                      ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-400'
                      : 'bg-slate-900/60 border-slate-800 text-slate-500'
                  }`}
                >
                  <span className="text-[10px] block font-semibold">D{item.day}</span>
                  <span className="text-[9px] font-mono font-bold block mt-0.5">
                    {completed ? <Check className="w-3 h-3 mx-auto text-emerald-400" /> : `${item.amount}`}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Claim or Dismiss Button */}
        {alreadyClaimed ? (
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm tracking-wide transition-colors cursor-pointer"
          >
            Fechar e Voltar aos Jogos
          </button>
        ) : (
          <button
            onClick={handleClaim}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-black text-base shadow-xl shadow-amber-500/30 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Gift className="w-5 h-5 fill-current" />
            <span>Coletar +{bonusAmount.toLocaleString('pt-BR')} Fichas</span>
          </button>
        )}
      </div>
    </div>
  );
};
