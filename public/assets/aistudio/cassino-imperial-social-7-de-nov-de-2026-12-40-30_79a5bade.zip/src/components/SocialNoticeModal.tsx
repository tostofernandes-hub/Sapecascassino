import React from 'react';
import { ShieldCheck, X, Coins, Sparkles, AlertCircle } from 'lucide-react';

interface SocialNoticeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SocialNoticeModal: React.FC<SocialNoticeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0f1713] border border-amber-500/40 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800/60 transition-colors"
          aria-label="Fechar"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-cinzel text-xl font-bold text-amber-300">
              Cassino Social Sem Dinheiro Real
            </h3>
            <p className="text-xs text-emerald-400 font-medium">
              Entretenimento 100% gratuito e seguro
            </p>
          </div>
        </div>

        <div className="space-y-3.5 text-sm text-slate-300 leading-relaxed mb-6">
          <div className="flex items-start gap-2.5">
            <Coins className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-white">Moeda 100% Fictícia:</strong> Você começa com <strong>1.000 Fichas</strong> virtuais. Todas as apostas, ganhos e saldos são simulados para diversão.
            </p>
          </div>

          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-white">Sem Depósitos ou Saques:</strong> Não há meios de pagamento, compras no aplicativo nem qualquer possibilidade de conversão de fichas para dinheiro real.
            </p>
          </div>

          <div className="flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-white">Fichas Infinitas Grátis:</strong> Se o seu saldo zerar, utilize o botão de recarga no topo ou no lobby para ganhar instantaneamente mais +1.000 fichas.
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
        >
          Entendido, Vamos Jogar!
        </button>
      </div>
    </div>
  );
};
