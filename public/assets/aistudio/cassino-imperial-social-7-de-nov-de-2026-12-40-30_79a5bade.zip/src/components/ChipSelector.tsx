import React from 'react';
import { soundManager } from '../utils/audio';

interface ChipSelectorProps {
  currentBet: number;
  balance: number;
  onBetChange: (newBet: number) => void;
  disabled?: boolean;
  minBet?: number;
  maxBet?: number;
}

const CHIP_VALUES = [
  { value: 10, bg: 'from-blue-600 to-blue-800', border: 'border-blue-400', text: '10' },
  { value: 25, bg: 'from-emerald-600 to-emerald-800', border: 'border-emerald-400', text: '25' },
  { value: 50, bg: 'from-red-600 to-red-800', border: 'border-red-400', text: '50' },
  { value: 100, bg: 'from-slate-900 to-amber-950', border: 'border-amber-400', text: '100' },
  { value: 500, bg: 'from-purple-700 to-purple-950', border: 'border-purple-400', text: '500' }
];

export const ChipSelector: React.FC<ChipSelectorProps> = ({
  currentBet,
  balance,
  onBetChange,
  disabled = false,
  minBet = 10,
  maxBet
}) => {
  const effectiveMax = maxBet !== undefined ? Math.min(balance, maxBet) : balance;

  const handleAddChip = (val: number) => {
    if (disabled) return;
    const next = Math.min(effectiveMax, currentBet + val);
    if (next !== currentBet) {
      soundManager.playChip();
      onBetChange(next);
    }
  };

  const handleClear = () => {
    if (disabled || currentBet === 0) return;
    soundManager.playClick();
    onBetChange(0);
  };

  const handleAllIn = () => {
    if (disabled || balance <= 0) return;
    soundManager.playChip();
    onBetChange(effectiveMax);
  };

  const handleDouble = () => {
    if (disabled || currentBet <= 0) return;
    const next = Math.min(effectiveMax, currentBet * 2);
    if (next !== currentBet) {
      soundManager.playChip();
      onBetChange(next);
    }
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900/90 border border-amber-500/20 rounded-xl px-3 py-2 shadow-md">
      {/* Current Bet Display */}
      <div className="flex items-center gap-1.5">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          Aposta:
        </span>
        <div className="flex items-center gap-1 bg-slate-950 px-2.5 py-1 rounded-lg border border-amber-500/40">
          <span className="text-amber-400 text-xs">🪙</span>
          <span className="font-mono text-sm font-bold text-amber-300 tabular-nums">
            {currentBet.toLocaleString('pt-BR')}
          </span>
          <span className="text-[10px] text-slate-400">fichas</span>
        </div>
      </div>

      {/* Chips buttons */}
      <div className="flex items-center gap-1.5 flex-wrap justify-center">
        {CHIP_VALUES.map((chip) => {
          const canAdd = !disabled && currentBet + chip.value <= effectiveMax;
          return (
            <button
              key={chip.value}
              type="button"
              disabled={!canAdd}
              onClick={() => handleAddChip(chip.value)}
              className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b ${chip.bg} border border-dashed ${chip.border} shadow flex items-center justify-center font-bold text-[11px] text-white select-none transition-transform active:scale-90 ${
                canAdd ? 'hover:-translate-y-0.5 cursor-pointer opacity-100' : 'opacity-35 cursor-not-allowed'
              }`}
              title={`Adicionar ${chip.value} fichas`}
            >
              {chip.text}
            </button>
          );
        })}
      </div>

      {/* Action shortcuts */}
      <div className="flex items-center gap-1">
        <button
          type="button"
          disabled={disabled || currentBet === 0}
          onClick={handleClear}
          className="px-2 py-1 text-[11px] font-medium rounded bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          Limpar
        </button>
        <button
          type="button"
          disabled={disabled || currentBet * 2 > effectiveMax || currentBet === 0}
          onClick={handleDouble}
          className="px-2 py-1 text-[11px] font-medium rounded bg-slate-800 text-amber-300 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          2x
        </button>
        <button
          type="button"
          disabled={disabled || balance <= 0 || currentBet === effectiveMax}
          onClick={handleAllIn}
          className="px-2 py-1 text-[11px] font-bold rounded bg-amber-600 text-slate-950 hover:bg-amber-500 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          All-In
        </button>
      </div>
    </div>
  );
};
