import React, { useState } from 'react';
import { Card, PokerHandResult } from '../types/casino';
import { createDeck, shuffleDeck, evaluateVideoPokerHand, POKER_PAYTABLE } from '../utils/cards';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { PlayingCard } from '../components/PlayingCard';
import { ChipSelector } from '../components/ChipSelector';
import { HowToPlayModal } from '../components/HowToPlayModal';
import { ArrowLeft, Play, RefreshCw, Trophy, HelpCircle } from 'lucide-react';

interface VideoPokerGameProps {
  balance: number;
  onUpdateBalance: (delta: number, isWin: boolean, gameId: 'video-poker', betAmount?: number) => void;
  onBackToLobby: () => void;
}

type PokerPhase = 'BETTING' | 'DRAW_HOLD' | 'ROUND_OVER';

export const VideoPokerGame: React.FC<VideoPokerGameProps> = ({
  balance,
  onUpdateBalance,
  onBackToLobby
}) => {
  const [bet, setBet] = useState<number>(25);
  const [phase, setPhase] = useState<PokerPhase>('BETTING');
  const [deck, setDeck] = useState<Card[]>([]);
  const [hand, setHand] = useState<Card[]>([]);
  const [heldIndices, setHeldIndices] = useState<boolean[]>([false, false, false, false, false]);
  const [result, setResult] = useState<PokerHandResult | null>(null);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  // Step 1: Deal initial 5 cards
  const handleDeal = () => {
    if (bet <= 0 || bet > balance) return;

    soundManager.playShuffle();
    onUpdateBalance(-bet, false, 'video-poker');

    const newDeck = shuffleDeck(createDeck());
    const initialHand = [
      newDeck.pop()!,
      newDeck.pop()!,
      newDeck.pop()!,
      newDeck.pop()!,
      newDeck.pop()!
    ];

    setDeck(newDeck);
    setHand(initialHand);
    setHeldIndices([false, false, false, false, false]);
    setResult(null);
    setPhase('DRAW_HOLD');
  };

  // Toggle hold on a card
  const toggleHold = (index: number) => {
    if (phase !== 'DRAW_HOLD') return;
    soundManager.playClick();
    setHeldIndices((prev) => {
      const copy = [...prev];
      copy[index] = !copy[index];
      return copy;
    });
  };

  // Step 2: Draw new cards for non-held slots and evaluate
  const handleDraw = () => {
    if (phase !== 'DRAW_HOLD' || deck.length < 5) return;

    soundManager.playCardDeal();
    const currentDeck = [...deck];
    const finalHand = hand.map((card, idx) => {
      if (heldIndices[idx]) {
        return card;
      }
      return currentDeck.pop()!;
    });

    setDeck(currentDeck);
    setHand(finalHand);

    // Evaluate final poker hand
    const handResult = evaluateVideoPokerHand(finalHand);
    setResult(handResult);
    setPhase('ROUND_OVER');

    if (handResult.payoutMultiplier > 0) {
      const totalWin = bet * handResult.payoutMultiplier;
      if (handResult.rank === 'ROYAL_FLUSH' || handResult.rank === 'STRAIGHT_FLUSH') {
        soundManager.playJackpot();
        fireConfetti(3500);
      } else {
        soundManager.playWin();
        fireConfetti(1800);
      }
      onUpdateBalance(totalWin, true, 'video-poker', bet);
    } else {
      soundManager.playLoss();
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fade-in pb-10">
      {/* Top Bar Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Lobby</span>
        </button>

        <button
          onClick={() => setShowHowToPlay(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
          <span>Como Jogar</span>
        </button>
      </div>

      {/* Paytable Matrix */}
      <div className="bg-[#09150f] border border-amber-500/30 rounded-xl p-2.5 shadow-lg overflow-x-auto">
        <div className="flex items-center justify-between mb-1.5 text-xs">
          <span className="font-cinzel font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1 text-[11px]">
            <Trophy className="w-3 h-3 text-amber-400" /> Tabela de Pagamentos
          </span>
          <span className="text-[11px] text-slate-400">
            Aposta: <strong className="text-amber-400 font-mono">{bet}</strong> fichas
          </span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-9 gap-1 text-center text-[11px]">
          {POKER_PAYTABLE.map((row) => {
            const isHighlight = result?.rank === row.rank;
            return (
              <div
                key={row.rank}
                className={`py-1 px-1.5 rounded border transition-all ${
                  isHighlight
                    ? 'bg-amber-500 text-slate-950 font-bold border-amber-300 ring-2 ring-white scale-105 shadow'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300'
                }`}
              >
                <div className="truncate font-semibold text-[10px] sm:text-[11px]">{row.name}</div>
                <div className="font-mono text-[10px] text-amber-300 font-bold">
                  {row.multiplier}x ({bet * row.multiplier})
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Poker Table Felt */}
      <div className="casino-felt casino-wood-border rounded-2xl p-4 sm:p-5 min-h-[250px] sm:min-h-[280px] flex flex-col justify-between shadow-xl relative">
        {/* Subtle Watermark */}
        <div className="text-center">
          <span className="text-[11px] text-amber-400/60 font-cinzel tracking-widest uppercase block">
            Jacks or Better · 5 Card Draw
          </span>
          {phase === 'DRAW_HOLD' && (
            <p className="text-[11px] text-amber-300 font-semibold animate-pulse mt-0.5">
              Clique nas cartas para MANTER antes de trocar
            </p>
          )}
        </div>

        {/* 5 Cards Row */}
        <div className="flex items-center justify-center gap-2 sm:gap-3 my-2 flex-wrap">
          {hand.length === 0
            ? Array.from({ length: 5 }).map((_, idx) => (
                <PlayingCard key={idx} hidden={true} size="sm" />
              ))
            : hand.map((card, idx) => (
                <PlayingCard
                  key={card.id || idx}
                  card={card}
                  held={heldIndices[idx]}
                  onToggleHold={phase === 'DRAW_HOLD' ? () => toggleHold(idx) : undefined}
                  size="sm"
                />
              ))}
        </div>

        {/* Round Outcome Banner */}
        <div className="text-center min-h-[36px] flex items-center justify-center">
          {result && (
            <div
              className={`px-4 py-1.5 rounded-lg font-cinzel font-bold text-xs sm:text-sm shadow-xl border ${
                result.payoutMultiplier > 0
                  ? 'bg-amber-500 text-slate-950 border-amber-300 animate-bounce'
                  : 'bg-slate-900 border-slate-700 text-slate-300'
              }`}
            >
              {result.name}! {result.payoutMultiplier > 0 ? `+${bet * result.payoutMultiplier} fichas!` : result.description}
            </div>
          )}
        </div>
      </div>

      {/* Controls & Chip Selector */}
      <div className="space-y-2.5">
        {phase === 'DRAW_HOLD' ? (
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-lg">
            <span className="text-xs text-slate-300">
              Mantidas:{' '}
              <strong className="text-amber-400 font-bold">
                {heldIndices.filter(Boolean).length} de 5
              </strong>
            </span>

            <button
              type="button"
              onClick={handleDraw}
              className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white font-cinzel font-bold text-xs sm:text-sm shadow transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Trocar e Avaliar</span>
            </button>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="flex-1">
              <ChipSelector
                currentBet={bet}
                balance={balance}
                onBetChange={setBet}
                disabled={false}
              />
            </div>

            <button
              type="button"
              onClick={handleDeal}
              disabled={bet <= 0 || bet > balance}
              className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-bold text-sm shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{phase === 'ROUND_OVER' ? 'Nova Mão' : 'Distribuir 5 Cartas'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Rules Modal */}
      <HowToPlayModal
        isOpen={showHowToPlay}
        onClose={() => setShowHowToPlay(false)}
        gameId="video-poker"
      />
    </div>
  );
};
