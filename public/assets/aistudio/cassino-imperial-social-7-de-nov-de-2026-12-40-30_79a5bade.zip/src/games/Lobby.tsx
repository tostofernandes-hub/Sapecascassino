import React from 'react';
import { GameId, PlayerStats } from '../types/casino';
import { Sparkles, Trophy, ArrowRight, ShieldCheck, Flame } from 'lucide-react';
import { soundManager } from '../utils/audio';
import { GameCardIllustration } from '../components/GameCardIllustration';

interface LobbyProps {
  onSelectGame: (game: GameId) => void;
  stats: PlayerStats;
  onRefillChips: () => void;
  onOpenSocialModal: () => void;
}

interface GameCardItem {
  id: GameId;
  title: string;
  badge: string;
  category: string;
  description: string;
  payoutMax: string;
  iconBg: string;
  iconSymbol: string;
}

const GAMES: GameCardItem[] = [
  {
    id: 'blackjack',
    title: 'Blackjack (21)',
    badge: 'Mesa Clássica',
    category: 'Cartas',
    description: 'Enfrente o dealer, peça cartas ou pare para somar 21 sem estourar. Blackjack natural paga 3:2.',
    payoutMax: '3:2',
    iconBg: 'from-emerald-600 to-emerald-950',
    iconSymbol: '♠'
  },
  {
    id: 'roulette',
    title: 'Roleta Europeia',
    badge: 'Roda da Fortuna',
    category: 'Mesa',
    description: '37 números (0 a 36). Aposte em número pleno, vermelho ou preto, par ou ímpar e dúzias.',
    payoutMax: '35:1',
    iconBg: 'from-red-600 to-amber-950',
    iconSymbol: '🎡'
  },
  {
    id: 'texas-holdem',
    title: "Pôquer Texas Hold'em",
    badge: 'Duelo Contra a Casa',
    category: 'Cartas',
    description: '2 cartas na mão e 5 comunitárias. Tome decisões no Flop, Turn e River com Call, Raise ou Fold.',
    payoutMax: '100:1',
    iconBg: 'from-indigo-600 to-indigo-950',
    iconSymbol: '♠'
  },
  {
    id: 'video-poker',
    title: 'Vídeo Pôquer',
    badge: 'Jacks or Better',
    category: 'Cartas',
    description: '5 cartas distribuídas. Escolha quais manter e trocar com tabela de pagamentos até o Royal Flush.',
    payoutMax: '250:1',
    iconBg: 'from-blue-600 to-indigo-950',
    iconSymbol: '🃏'
  },
  {
    id: 'baccarat',
    title: 'Bacarate (Baccarat)',
    badge: 'Alta Elegância',
    category: 'Mesa',
    description: 'Aposte no Jogador, na Banca ou no Empate. Regras clássicas de terceira carta e soma mod 10.',
    payoutMax: '8:1',
    iconBg: 'from-amber-600 to-yellow-950',
    iconSymbol: '👑'
  },
  {
    id: 'slots',
    title: 'Caça-Níquel Fortune',
    badge: 'Estilo Tigrinho',
    category: 'Caça-Níquel',
    description: 'Bobinas 3x3 com temas dinâmicos (Tigre da Selva, Frutas de Ouro, Egito). Multiplicadores até 100x!',
    payoutMax: '100x',
    iconBg: 'from-amber-500 to-red-950',
    iconSymbol: '🐯'
  },
  {
    id: 'lottery',
    title: 'Loteria Mega',
    badge: 'Sorteio das 6 Dezenas',
    category: 'Loteria',
    description: 'Escolha de 6 a 15 números entre 1 e 60. Sorteio de 6 bolas ao vivo com faixas de 4, 5 e 6 acertos.',
    payoutMax: '50.000x',
    iconBg: 'from-emerald-500 to-teal-950',
    iconSymbol: '🎱'
  }
];

export const Lobby: React.FC<LobbyProps> = ({
  onSelectGame,
  stats,
  onRefillChips,
  onOpenSocialModal
}) => {
  const handleGameClick = (id: GameId) => {
    soundManager.playClick();
    onSelectGame(id);
  };

  return (
    <div className="space-y-10 animate-fade-in pb-10">
      {/* Hero Welcome Banner */}
      <section className="relative overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-br from-[#0c2417] via-[#09150f] to-[#060a08] p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold uppercase tracking-widest">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Cassino Social Sem Risco Financeiro</span>
            <span aria-hidden="true">·</span>
            <span>100% Fictício</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-cinzel leading-tight text-wrap-balance">
            Bem-vindo ao <span className="text-gold-gradient">Cassino Imperial</span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl">
            Desfrute da atmosfera refinada dos maiores salões de jogos do mundo sem gastar um único centavo. Todas as apostas usam fichas virtuais gratuitas. Experimente Blackjack, Roleta, Vídeo Pôquer, Bacará, Slots e Loteria!
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4">
            <button
              onClick={() => handleGameClick('slots')}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>Jogar Caça-Níquel Tigrinho</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenSocialModal}
              className="px-4 py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-sm font-medium transition-colors flex items-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Aviso de Cassino Social</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Strip */}
        <div className="mt-8 pt-6 border-t border-amber-500/20 grid grid-cols-2 sm:grid-cols-4 gap-4 text-slate-300">
          <div>
            <span className="text-xs text-slate-400 block">Saldo em Fichas</span>
            <span className="font-mono text-xl font-bold text-amber-300 tabular-nums">
              {stats.chips.toLocaleString('pt-BR')}
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-400 block">Maior Saldo Alcançado</span>
            <span className="font-mono text-xl font-bold text-emerald-400 tabular-nums">
              {stats.highestBalance.toLocaleString('pt-BR')}
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-400 block">Maior Vitória Única</span>
            <span className="font-mono text-xl font-bold text-amber-400 tabular-nums">
              +{stats.biggestWin.toLocaleString('pt-BR')}
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-400 block">Sequência Atual</span>
            <span className="font-mono text-xl font-bold text-purple-400 tabular-nums flex items-center gap-1">
              <Flame className="w-4 h-4 text-amber-500" />
              {stats.currentStreak} {stats.currentStreak === 1 ? 'vitória' : 'vitórias'}
            </span>
          </div>
        </div>
      </section>

      {/* Games Catalog Section */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <h2 className="text-2xl font-bold text-white font-cinzel">
              Salão Principal de Jogos
            </h2>
            <p className="text-sm text-slate-400">
              Escolha uma mesa e comece a girar, apostar ou pedir cartas.
            </p>
          </div>

          <button
            onClick={() => handleGameClick('records')}
            className="text-sm text-amber-400 hover:text-amber-300 flex items-center gap-1.5 font-semibold cursor-pointer group"
          >
            <Trophy className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
            <span>Ver Placar de Recordes</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {GAMES.map((game) => (
            <div
              key={game.id}
              onClick={() => handleGameClick(game.id)}
              className="group relative bg-[#0c1410] hover:bg-[#111c16] border border-amber-500/20 hover:border-amber-400/80 rounded-2xl overflow-hidden p-4 shadow-lg hover:shadow-2xl hover:shadow-amber-500/10 transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              <div>
                {/* Clickable Illustrative Image Container with Hover Zoom & Glow */}
                <div className="relative overflow-hidden rounded-xl border border-amber-500/30 mb-4 group-hover:border-amber-400 transition-colors">
                  <div className="transition-transform duration-500 ease-out group-hover:scale-105">
                    <GameCardIllustration gameId={game.id} />
                  </div>
                  
                  {/* Subtle Top Badge Overlay */}
                  <div className="absolute top-2.5 right-2.5 bg-slate-950/80 backdrop-blur-md border border-amber-500/40 px-2 py-0.5 rounded text-[10px] font-bold text-amber-300 uppercase tracking-wider shadow">
                    {game.badge}
                  </div>
                </div>

                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <h3 className="text-lg font-bold text-white font-cinzel group-hover:text-amber-300 transition-colors">
                    {game.title}
                  </h3>
                  <span className="text-[11px] font-mono text-amber-400/90 whitespace-nowrap mt-0.5 font-semibold">
                    Até {game.payoutMax}
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                  {game.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">
                  {game.category} · Sem dinheiro real
                </span>
                <span className="font-bold text-amber-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  Entrar no Jogo <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Bonus Refill Callout if needed */}
      <section className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="font-semibold text-white text-sm">
            Ficou sem fichas ou quer aumentar seu saldo de teste?
          </h4>
          <p className="text-xs text-slate-400">
            Você pode resgatar +1.000 fichas bônus instantaneamente a qualquer momento.
          </p>
        </div>
        <button
          onClick={onRefillChips}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition-colors cursor-pointer whitespace-nowrap"
        >
          Recarregar +1.000 Fichas Grátis
        </button>
      </section>
    </div>
  );
};
