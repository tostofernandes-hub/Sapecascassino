import React, { useState } from 'react';
import { PlayerStats } from '../types/casino';
import { soundManager } from '../utils/audio';
import {
  ArrowLeft,
  Trophy,
  Flame,
  Coins,
  RotateCcw,
  Award,
  CheckCircle,
  AlertTriangle,
  Lock,
  Sparkles
} from 'lucide-react';
import { ACHIEVEMENTS, Achievement } from '../utils/achievements';

interface RecordsViewProps {
  stats: PlayerStats;
  onResetRecords: () => void;
  onBackToLobby: () => void;
}

const GAME_NAMES: Record<string, string> = {
  blackjack: 'Blackjack (21)',
  roulette: 'Roleta Europeia',
  'texas-holdem': "Pôquer Texas Hold'em",
  'video-poker': 'Vídeo Pôquer',
  baccarat: 'Bacarate',
  slots: 'Caça-Níquel Fortune',
  lottery: 'Loteria Mega'
};

export const RecordsView: React.FC<RecordsViewProps> = ({
  stats,
  onResetRecords,
  onBackToLobby
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState<boolean>(false);
  const [badgeFilter, setBadgeFilter] = useState<'all' | 'unlocked' | 'locked'>('all');

  // Sort games by wins descending
  const sortedGames = Object.entries(stats.gameWins).sort(([, a], [, b]) => b - a);
  const totalWins = Object.values(stats.gameWins).reduce((sum, w) => sum + w, 0);

  // Compute achievements status
  const achievementsWithStatus = ACHIEVEMENTS.map((ach) => {
    const isUnlocked = ach.checkUnlocked(stats);
    const progress = ach.getProgress(stats);
    return {
      ...ach,
      isUnlocked,
      progress
    };
  });

  const unlockedCount = achievementsWithStatus.filter((a) => a.isUnlocked).length;
  const totalAchievements = achievementsWithStatus.length;
  const completionPercentage = Math.round((unlockedCount / totalAchievements) * 100);

  const filteredAchievements = achievementsWithStatus.filter((a) => {
    if (badgeFilter === 'unlocked') return a.isUnlocked;
    if (badgeFilter === 'locked') return !a.isUnlocked;
    return true;
  });

  const handleConfirmReset = () => {
    soundManager.playClick();
    onResetRecords();
    setShowConfirmReset(false);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-fade-in pb-12">
      {/* Top Header Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Lobby</span>
        </button>

        <span className="text-xs text-amber-400 font-bold uppercase tracking-wider">
          Estatísticas & Conquistas
        </span>
      </div>

      {/* Main Title Section */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 mb-2">
          <Trophy className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-white font-cinzel">
          Placar de Recordes Imperial
        </h1>
        <p className="text-sm text-slate-400">
          Seu histórico de desempenho, insígnias conquistadas e jogos mais lucrativos.
        </p>
      </div>

      {/* Top 4 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Maior Saldo */}
        <div className="bg-[#0d1612] border border-amber-500/30 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-slate-400 font-medium">Maior Saldo Alcançado</span>
            <Coins className="w-4 h-4 text-amber-400" />
          </div>
          <div className="font-mono text-2xl font-bold text-amber-300 tabular-nums">
            {stats.highestBalance.toLocaleString('pt-BR')}
          </div>
          <span className="text-[11px] text-slate-500 mt-2">
            Recorde em: {stats.recordDate || 'Hoje'}
          </span>
        </div>

        {/* Maior Vitória */}
        <div className="bg-[#0d1612] border border-emerald-500/30 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-slate-400 font-medium">Maior Vitória Única</span>
            <Award className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="font-mono text-2xl font-bold text-emerald-400 tabular-nums">
            +{stats.biggestWin.toLocaleString('pt-BR')}
          </div>
          <span className="text-[11px] text-slate-500 mt-2">
            Em uma única rodada
          </span>
        </div>

        {/* Sequência de Vitórias */}
        <div className="bg-[#0d1612] border border-purple-500/30 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-slate-400 font-medium">Maior Sequência</span>
            <Flame className="w-4 h-4 text-purple-400" />
          </div>
          <div className="font-mono text-2xl font-bold text-purple-300 tabular-nums">
            {stats.longestStreak} vitórias
          </div>
          <span className="text-[11px] text-slate-500 mt-2">
            Atual: {stats.currentStreak} consecutivas
          </span>
        </div>

        {/* Total Rodadas & Vitórias */}
        <div className="bg-[#0d1612] border border-blue-500/30 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-slate-400 font-medium">Total de Rodadas</span>
            <CheckCircle className="w-4 h-4 text-blue-400" />
          </div>
          <div className="font-mono text-2xl font-bold text-blue-300 tabular-nums">
            {stats.totalRounds}
          </div>
          <span className="text-[11px] text-slate-500 mt-2">
            {totalWins} vitórias registradas
          </span>
        </div>
      </div>

      {/* SECTION: SISTEMA DE CONQUISTAS (BADGES) */}
      <div className="bg-[#09150f] border border-amber-500/30 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <h2 className="text-lg font-bold text-white font-cinzel">
                Insígnias & Conquistas (Badges)
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Desbloqueie medalhas alcançando metas de rodadas, grandes vitórias e maestria nos jogos.
            </p>
          </div>

          {/* Completion Status Pill */}
          <div className="flex items-center gap-3">
            <div className="bg-slate-900/90 border border-amber-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-mono font-bold text-amber-300">
                {unlockedCount} / {totalAchievements} ({completionPercentage}%)
              </span>
            </div>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setBadgeFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              badgeFilter === 'all'
                ? 'bg-amber-500 text-slate-950 font-bold shadow'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Todas ({totalAchievements})
          </button>
          <button
            type="button"
            onClick={() => setBadgeFilter('unlocked')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              badgeFilter === 'unlocked'
                ? 'bg-emerald-600 text-white font-bold shadow'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Desbloqueadas ({unlockedCount})
          </button>
          <button
            type="button"
            onClick={() => setBadgeFilter('locked')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              badgeFilter === 'locked'
                ? 'bg-slate-700 text-white font-bold shadow'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            A Conquistar ({totalAchievements - unlockedCount})
          </button>
        </div>

        {/* Grid of Badges */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
          {filteredAchievements.map((badge) => {
            const progressPercent = Math.min(
              100,
              Math.round((badge.progress.current / badge.progress.max) * 100)
            );
            return (
              <div
                key={badge.id}
                className={`relative rounded-xl border p-4 transition-all flex flex-col justify-between ${
                  badge.isUnlocked
                    ? 'bg-gradient-to-br from-[#122319] to-[#0c1811] border-amber-500/50 shadow-md ring-1 ring-amber-400/30'
                    : 'bg-slate-900/60 border-slate-800/80 opacity-75'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  {/* Badge Medal Icon */}
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0 shadow-lg border transition-transform ${
                      badge.isUnlocked
                        ? 'bg-gradient-to-br from-amber-400 to-amber-700 border-amber-300 text-slate-950 scale-105 shadow-amber-500/20'
                        : 'bg-slate-800 border-slate-700 text-slate-500 grayscale'
                    }`}
                  >
                    <span>{badge.icon}</span>
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h3
                        className={`text-sm font-bold truncate ${
                          badge.isUnlocked ? 'text-amber-300 font-cinzel' : 'text-slate-300'
                        }`}
                      >
                        {badge.title}
                      </h3>

                      {badge.isUnlocked ? (
                        <span className="shrink-0 inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/50 text-emerald-400 uppercase tracking-wider">
                          <CheckCircle className="w-3 h-3" />
                          Desbloqueada
                        </span>
                      ) : (
                        <span className="shrink-0 inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-400 uppercase tracking-wider">
                          <Lock className="w-3 h-3" />
                          Bloqueada
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-400 mt-1 leading-snug">
                      {badge.description}
                    </p>
                  </div>
                </div>

                {/* Progress bar and label */}
                <div className="mt-3.5 pt-2.5 border-t border-slate-800/60">
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="text-slate-500 font-medium">Progresso:</span>
                    <span
                      className={`font-mono font-bold ${
                        badge.isUnlocked ? 'text-amber-400' : 'text-slate-400'
                      }`}
                    >
                      {badge.progress.label}
                    </span>
                  </div>

                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        badge.isUnlocked
                          ? 'bg-gradient-to-r from-amber-500 to-emerald-400'
                          : 'bg-slate-600'
                      }`}
                      style={{ width: `${Math.max(badge.isUnlocked ? 100 : 2, progressPercent)}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Ranking dos Jogos com mais Vitórias */}
      <div className="bg-[#09150f] border border-amber-500/30 rounded-2xl p-6 shadow-xl space-y-4">
        <h2 className="text-lg font-bold text-white font-cinzel flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-400" />
          Ranking de Vitórias por Jogo
        </h2>

        <div className="space-y-3 pt-2">
          {sortedGames.map(([gameKey, wins], idx) => {
            const percentage = totalWins > 0 ? Math.round((wins / totalWins) * 100) : 0;
            return (
              <div
                key={gameKey}
                className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                      idx === 0
                        ? 'bg-amber-500 text-slate-950 font-black'
                        : idx === 1
                        ? 'bg-slate-300 text-slate-950'
                        : idx === 2
                        ? 'bg-amber-800 text-amber-100'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    #{idx + 1}
                  </span>
                  <div>
                    <span className="font-semibold text-sm text-white block">
                      {GAME_NAMES[gameKey] || gameKey}
                    </span>
                    <span className="text-xs text-slate-400">
                      {percentage}% de todas as vitórias
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {/* Progress bar */}
                  <div className="w-28 sm:w-40 bg-slate-800 rounded-full h-2.5 overflow-hidden hidden sm:block">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-amber-300 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.max(5, percentage)}%` }}
                    />
                  </div>

                  <span className="font-mono text-sm font-bold text-amber-300 tabular-nums">
                    {wins} {wins === 1 ? 'vitória' : 'vitórias'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Reset Confirmation Button & Modal */}
      <div className="pt-4 flex justify-end">
        <button
          type="button"
          onClick={() => setShowConfirmReset(true)}
          className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1.5 font-medium transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Resetar Todos os Recordes</span>
        </button>
      </div>

      {/* Confirmation Modal */}
      {showConfirmReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#121c16] border border-red-500/40 rounded-2xl max-w-sm w-full p-6 shadow-2xl space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="font-cinzel text-lg font-bold text-white">
              Resetar Recordes?
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed">
              Tem certeza que deseja zerar seu maior saldo, maiores vitórias e histórico de jogos? Esta ação não pode ser desfeita.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmReset}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors"
              >
                Sim, Resetar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
