import React, { useState, useEffect, useRef } from 'react';
import { GameId, PlayerStats } from './types/casino';
import { soundManager } from './utils/audio';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SocialNoticeModal } from './components/SocialNoticeModal';
import { Lobby } from './games/Lobby';
import { BlackjackGame } from './games/BlackjackGame';
import { RouletteGame } from './games/RouletteGame';
import { VideoPokerGame } from './games/VideoPokerGame';
import { BaccaratGame } from './games/BaccaratGame';
import { TexasHoldemGame } from './games/TexasHoldemGame';
import { SlotsGame } from './games/SlotsGame';
import { LotteryGame } from './games/LotteryGame';
import { RecordsView } from './games/RecordsView';

import { DailyBonusModal } from './components/DailyBonusModal';
import { BigWinCelebration } from './components/BigWinCelebration';

const STORAGE_KEY = 'casino_player_stats_v1';

const DEFAULT_STATS: PlayerStats = {
  chips: 1000,
  highestBalance: 1000,
  biggestWin: 0,
  currentStreak: 0,
  longestStreak: 0,
  recordDate: new Date().toLocaleDateString('pt-BR'),
  lastDailyBonusDate: '',
  dailyLoginStreak: 0,
  gameWins: {
    blackjack: 0,
    roulette: 0,
    'texas-holdem': 0,
    'video-poker': 0,
    baccarat: 0,
    slots: 0,
    lottery: 0
  },
  totalRounds: 0
};

export default function App() {
  const [activeGame, setActiveGame] = useState<GameId>('lobby');
  const [isMuted, setIsMuted] = useState<boolean>(soundManager.getMuted());
  const [socialModalOpen, setSocialModalOpen] = useState<boolean>(false);
  const [dailyBonusOpen, setDailyBonusOpen] = useState<boolean>(false);
  const [bigWinState, setBigWinState] = useState<{
    isOpen: boolean;
    winAmount: number;
    betAmount?: number;
  }>({
    isOpen: false,
    winAmount: 0,
    betAmount: 0
  });

  const lastBetsRef = useRef<Record<string, number>>({});
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_STATS, ...JSON.parse(saved) };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_STATS;
  });

  // Calculate Daily Bonus status based on today's calendar date
  const todayStr = new Date().toISOString().split('T')[0];
  const isDailyBonusAvailable = stats.lastDailyBonusDate !== todayStr;

  // Calculate streak: check if last bonus was yesterday
  const calculateStreak = (): number => {
    if (!stats.lastDailyBonusDate) return 1;
    if (stats.lastDailyBonusDate === todayStr) return stats.dailyLoginStreak || 1;
    
    const lastDate = new Date(stats.lastDailyBonusDate);
    const today = new Date(todayStr);
    const diffTime = Math.abs(today.getTime() - lastDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      return Math.min(7, (stats.dailyLoginStreak || 0) + 1);
    }
    return 1;
  };

  const streak = calculateStreak();
  const STREAK_AMOUNTS = [500, 750, 1000, 1250, 1500, 1750, 2500];
  const bonusAmount = STREAK_AMOUNTS[Math.max(0, Math.min(6, streak - 1))];

  const handleClaimDailyBonus = () => {
    const nextStreak = calculateStreak();
    const amount = STREAK_AMOUNTS[Math.max(0, Math.min(6, nextStreak - 1))];
    setStats((prev) => ({
      ...prev,
      chips: prev.chips + amount,
      highestBalance: Math.max(prev.highestBalance, prev.chips + amount),
      lastDailyBonusDate: todayStr,
      dailyLoginStreak: nextStreak
    }));
  };

  // Save stats to localStorage on every change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
    } catch {
      // Storage error fallback
    }
  }, [stats]);

  const handleToggleMute = () => {
    const nextMuted = soundManager.toggleMute();
    setIsMuted(nextMuted);
  };

  /**
   * Central balance and round stats updater
   */
  const handleUpdateBalance = (
    delta: number,
    isWin: boolean,
    gameId: 'blackjack' | 'roulette' | 'texas-holdem' | 'video-poker' | 'baccarat' | 'slots' | 'lottery',
    explicitBet?: number
  ) => {
    // Remember bet amount when deducted
    if (delta < 0 && !isWin) {
      lastBetsRef.current[gameId] = Math.abs(delta);
    }

    // Trigger 2-second Big Win celebration animation if win is greater than 2x the bet
    if (isWin && delta > 0) {
      const bet = explicitBet ?? lastBetsRef.current[gameId] ?? 0;
      if (bet > 0 && delta > 2 * bet) {
        setBigWinState({
          isOpen: true,
          winAmount: delta,
          betAmount: bet
        });
      }
    }

    setStats((prev) => {
      const newChips = Math.max(0, prev.chips + delta);
      const newHighest = Math.max(prev.highestBalance, newChips);
      const isNewRecord = newChips > prev.highestBalance;

      let newStreak = prev.currentStreak;
      let newLongest = prev.longestStreak;
      let newBiggestWin = prev.biggestWin;

      const updatedGameWins = { ...prev.gameWins };

      if (delta > 0 && isWin) {
        newStreak = prev.currentStreak + 1;
        newLongest = Math.max(newLongest, newStreak);
        newBiggestWin = Math.max(newBiggestWin, delta);
        updatedGameWins[gameId] = (updatedGameWins[gameId] || 0) + 1;
      } else if (delta < 0 && !isWin) {
        // If a round resulted in loss
        newStreak = 0;
      }

      return {
        ...prev,
        chips: newChips,
        highestBalance: newHighest,
        biggestWin: newBiggestWin,
        currentStreak: newStreak,
        longestStreak: newLongest,
        recordDate: isNewRecord ? new Date().toLocaleDateString('pt-BR') : prev.recordDate,
        gameWins: updatedGameWins,
        totalRounds: prev.totalRounds + (delta < 0 ? 1 : 0) // count rounds initiated
      };
    });
  };

  /**
   * Free chips refill (+1.000 Fichas)
   */
  const handleRefillChips = () => {
    soundManager.playWin();
    setStats((prev) => ({
      ...prev,
      chips: prev.chips + 1000,
      highestBalance: Math.max(prev.highestBalance, prev.chips + 1000)
    }));
  };

  /**
   * Reset high scores and statistics
   */
  const handleResetRecords = () => {
    const resetState: PlayerStats = {
      chips: 1000,
      highestBalance: 1000,
      biggestWin: 0,
      currentStreak: 0,
      longestStreak: 0,
      recordDate: new Date().toLocaleDateString('pt-BR'),
      lastDailyBonusDate: '',
      dailyLoginStreak: 0,
      gameWins: {
        blackjack: 0,
        roulette: 0,
        'texas-holdem': 0,
        'video-poker': 0,
        baccarat: 0,
        slots: 0,
        lottery: 0
      },
      totalRounds: 0
    };
    setStats(resetState);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070b09] text-slate-100 font-sans">
      {/* Top Bar Header */}
      <Header
        activeGame={activeGame}
        onNavigate={setActiveGame}
        balance={stats.chips}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenSocialModal={() => setSocialModalOpen(true)}
        onRefillChips={handleRefillChips}
        onOpenDailyBonus={() => setDailyBonusOpen(true)}
        hasDailyBonusAvailable={isDailyBonusAvailable}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-4 sm:py-6">
        {activeGame === 'lobby' && (
          <Lobby
            onSelectGame={setActiveGame}
            stats={stats}
            onRefillChips={handleRefillChips}
            onOpenSocialModal={() => setSocialModalOpen(true)}
          />
        )}

        {activeGame === 'blackjack' && (
          <BlackjackGame
            balance={stats.chips}
            onUpdateBalance={handleUpdateBalance}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}

        {activeGame === 'roulette' && (
          <RouletteGame
            balance={stats.chips}
            onUpdateBalance={handleUpdateBalance}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}

        {activeGame === 'texas-holdem' && (
          <TexasHoldemGame
            balance={stats.chips}
            onUpdateBalance={handleUpdateBalance}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}

        {activeGame === 'video-poker' && (
          <VideoPokerGame
            balance={stats.chips}
            onUpdateBalance={handleUpdateBalance}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}

        {activeGame === 'baccarat' && (
          <BaccaratGame
            balance={stats.chips}
            onUpdateBalance={handleUpdateBalance}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}

        {activeGame === 'slots' && (
          <SlotsGame
            balance={stats.chips}
            onUpdateBalance={handleUpdateBalance}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}

        {activeGame === 'lottery' && (
          <LotteryGame
            balance={stats.chips}
            onUpdateBalance={handleUpdateBalance}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}

        {activeGame === 'records' && (
          <RecordsView
            stats={stats}
            onResetRecords={handleResetRecords}
            onBackToLobby={() => setActiveGame('lobby')}
          />
        )}
      </main>

      {/* Footer */}
      <Footer onOpenSocialModal={() => setSocialModalOpen(true)} />

      {/* Social Notice Modal */}
      <SocialNoticeModal
        isOpen={socialModalOpen}
        onClose={() => setSocialModalOpen(false)}
      />

      {/* Daily Bonus Modal */}
      <DailyBonusModal
        isOpen={dailyBonusOpen}
        onClose={() => setDailyBonusOpen(false)}
        streak={streak}
        bonusAmount={bonusAmount}
        onClaim={handleClaimDailyBonus}
        alreadyClaimed={!isDailyBonusAvailable}
      />

      {/* Big Win Celebration (>2x Bet) using reference artwork */}
      <BigWinCelebration
        isOpen={bigWinState.isOpen}
        winAmount={bigWinState.winAmount}
        betAmount={bigWinState.betAmount}
        onClose={() => setBigWinState((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}
