/**
 * Audio Synthesizer utilizing Web Audio API without any external assets.
 * Generates soft, professional casino tones: clicks, dealing swooshes, roulette ticks,
 * wins, losses, and jackpot fanfares.
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    // Read preference from localStorage
    const savedMute = localStorage.getItem('casino_sound_muted');
    if (savedMute !== null) {
      this.isMuted = savedMute === 'true';
    }
  }

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    localStorage.setItem('casino_sound_muted', String(this.isMuted));
    if (!this.isMuted) {
      this.playClick();
    }
    return this.isMuted;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    localStorage.setItem('casino_sound_muted', String(this.isMuted));
  }

  /**
   * Generic tone helper
   */
  private playTone(freq: number, type: OscillatorType, duration: number, startVol = 0.15, endVol = 0.001, startTime = 0) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime + startTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(startVol, now);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, endVol), now + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + duration);
    } catch {
      // Audio playback fails gracefully if blocked by autoplay policy
    }
  }

  /**
   * Crisp UI click sound
   */
  public playClick() {
    this.playTone(600, 'triangle', 0.05, 0.1, 0.01);
  }

  /**
   * Sound of adding a chip to a bet
   */
  public playChip() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    // Two fast high micro-clicks resembling porcelain chips colliding
    this.playTone(1800, 'sine', 0.03, 0.08, 0.005, 0);
    this.playTone(2400, 'sine', 0.04, 0.06, 0.005, 0.02);
  }

  /**
   * Card deal swoosh / flick
   */
  public playCardDeal() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      // White noise buffer for paper snap
      const bufferSize = this.ctx.sampleRate * 0.05;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1200, now);
      filter.Q.setValueAtTime(3, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      whiteNoise.start(now);
    } catch {
      this.playTone(400, 'triangle', 0.04, 0.08, 0.01);
    }
  }

  /**
   * Shuffling deck sound
   */
  public playShuffle() {
    if (this.isMuted) return;
    for (let i = 0; i < 5; i++) {
      setTimeout(() => this.playCardDeal(), i * 45);
    }
  }

  /**
   * Roulette wheel ball tick (single ball bounce on pocket)
   */
  public playRouletteTick(pitch = 1200) {
    this.playTone(pitch, 'sine', 0.03, 0.09, 0.005);
  }

  /**
   * Slot machine reel spin tick
   */
  public playReelTick() {
    this.playTone(450, 'square', 0.02, 0.04, 0.005);
  }

  /**
   * Slot machine reel stop clunk
   */
  public playReelStop() {
    this.playTone(280, 'triangle', 0.08, 0.15, 0.01);
    this.playTone(140, 'sine', 0.1, 0.1, 0.01);
  }

  /**
   * Round victory arpeggio (C major / bright triad)
   */
  public playWin() {
    if (this.isMuted) return;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      this.playTone(freq, 'sine', 0.22, 0.15, 0.01, idx * 0.07);
    });
  }

  /**
   * Round loss gentle tone (descending, non-punishing)
   */
  public playLoss() {
    if (this.isMuted) return;
    this.playTone(330, 'triangle', 0.15, 0.08, 0.01, 0);
    this.playTone(260, 'sine', 0.25, 0.07, 0.01, 0.12);
  }

  /**
   * Grand Jackpot fanfare!
   */
  public playJackpot() {
    if (this.isMuted) return;
    const notes = [
      { f: 523.25, t: 0 },
      { f: 659.25, t: 0.08 },
      { f: 783.99, t: 0.16 },
      { f: 1046.5, t: 0.24 },
      { f: 783.99, t: 0.36 },
      { f: 1046.5, t: 0.44 },
      { f: 1318.51, t: 0.52 },
      { f: 1567.98, t: 0.64 }
    ];
    notes.forEach(({ f, t }) => {
      this.playTone(f, 'triangle', 0.3, 0.18, 0.01, t);
    });
  }
}

export const soundManager = new SoundManager();
