import React, { useState } from 'react';
import { Card } from '../types/casino';
import { createDeck, shuffleDeck, evaluate7CardHand, comparePokerHands, DetailedPokerHand } from '../utils/cards';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { PlayingCard } from '../components/PlayingCard';
import { ChipSelector } from '../components/ChipSelector';
import { HowToPlayModal } from '../components/HowToPlayModal';
import { ArrowLeft, Play, RotateCcw, HelpCircle, Check, ArrowUpRight, XCircle } from 'lucide-react';

interface TexasHoldemGameProps {
  balance: number;
  onUpdateBalance: (delta: number, isWin: boolean, gameId: 'texas-holdem', betAmount?: number) => void;
  onBackToLobby: () => void;
}

type HoldemStage = 'BETTING' | 'FLOP_ROUND' | 'TURN_ROUND' | 'SHOWDOWN';

export const TexasHoldemGame: React.FC<TexasHoldemGameProps> = ({
  balance,
  onUpdateBalance,
  onBackToLobby
}) => {
  const [anteBet, setAnteBet] = useState<number>(50);
  const [totalPot, setTotalPot] = useState<number>(0);
  const [stage, setStage] = useState<HoldemStage>('BETTING');
  const [deck, setDeck] = useState<Card[]>([]);
  
  const [playerCards, setPlayerCards] = useState<Card[]>([]);
  const [dealerCards, setDealerCards] = useState<Card[]>([]);
  const [communityCards, setCommunityCards] = useState<Card[]>([]);
  const [revealedCommunityCount, setRevealedCommunityCount] = useState<number>(0);

  const [playerHandResult, setPlayerHandResult] = useState<DetailedPokerHand | null>(null);
  const [dealerHandResult, setDealerHandResult] = useState<DetailedPokerHand | null>(null);

  const [outcome, setOutcome] = useState<'WIN' | 'LOSS' | 'TIE' | 'FOLD' | null>(null);
  const [outcomeMessage, setOutcomeMessage] = useState<string>('');
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  // Start new round
  const handleDealHand = () => {
    if (anteBet <= 0 || anteBet > balance) return;

    soundManager.playShuffle();
    onUpdateBalance(-anteBet, false, 'texas-holdem');

    const newDeck = shuffleDeck(createDeck());
    const p1 = newDeck.pop()!;
    const p2 = newDeck.pop()!;
    const d1 = newDeck.pop()!;
    const d2 = newDeck.pop()!;

    // 5 community cards prepared
    const comm1 = newDeck.pop()!;
    const comm2 = newDeck.pop()!;
    const comm3 = newDeck.pop()!;
    const comm4 = newDeck.pop()!;
    const comm5 = newDeck.pop()!;

    setPlayerCards([p1, p2]);
    setDealerCards([d1, d2]);
    setCommunityCards([comm1, comm2, comm3, comm4, comm5]);
    setRevealedCommunityCount(3); // Flop dealt immediately
    setDeck(newDeck);
    setTotalPot(anteBet * 2); // Ante matched by house
    setOutcome(null);
    setOutcomeMessage('');
    setStage('FLOP_ROUND');

    soundManager.playCardDeal();
  };

  // Player calls (checks/continues without adding or matching)
  const handleCall = () => {
    soundManager.playClick();
    advanceStreet(0);
  };

  // Player raises (adds another bet to pot)
  const handleRaise = () => {
    const raiseAmount = anteBet;
    if (balance < raiseAmount) return;

    soundManager.playChip();
    onUpdateBalance(-raiseAmount, false, 'texas-holdem');
    setTotalPot((prev) => prev + raiseAmount * 2); // House matches raise
    advanceStreet(raiseAmount);
  };

  // Player folds (concedes hand)
  const handleFold = () => {
    soundManager.playLoss();
    setStage('SHOWDOWN');
    setOutcome('FOLD');
    setOutcomeMessage('Você desistiu da mão (Fold). A casa recolhe o pote.');
  };

  const advanceStreet = (_addedBet: number) => {
    if (stage === 'FLOP_ROUND') {
      // Reveal Turn (4th card)
      soundManager.playCardDeal();
      setRevealedCommunityCount(4);
      setStage('TURN_ROUND');
    } else if (stage === 'TURN_ROUND') {
      // Reveal River (5th card) and proceed to Showdown
      soundManager.playCardDeal();
      setRevealedCommunityCount(5);
      triggerShowdown();
    }
  };

  const triggerShowdown = () => {
    setStage('SHOWDOWN');

    // Evaluate Player 7 cards
    const pFull = [...playerCards, ...communityCards];
    const dFull = [...dealerCards, ...communityCards];

    const pBest = evaluate7CardHand(pFull);
    const dBest = evaluate7CardHand(dFull);

    setPlayerHandResult(pBest);
    setDealerHandResult(dBest);

    const cmp = comparePokerHands(pBest, dBest);

    if (cmp > 0) {
      // Player Wins!
      let prizeMultiplier = 1;
      if (pBest.tier >= 6) prizeMultiplier = 2; // Full House or better bonus
      const totalWin = Math.floor(totalPot * prizeMultiplier);

      if (pBest.tier >= 6) {
        soundManager.playJackpot();
        fireConfetti(3500);
      } else {
        soundManager.playWin();
        fireConfetti(2200);
      }

      setOutcome('WIN');
      setOutcomeMessage(`VOCÊ VENCEU O POTE! (${pBest.name} vence ${dBest.name}). Ganhou +${totalWin} fichas!`);
      onUpdateBalance(totalWin, true, 'texas-holdem', anteBet + raiseAmount);
    } else if (cmp < 0) {
      // Dealer Wins
      soundManager.playLoss();
      setOutcome('LOSS');
      setOutcomeMessage(`A CASA VENCEU (${dBest.name} vence ${pBest.name}).`);
    } else {
      // Tie
      soundManager.playLoss();
      const split = Math.floor(totalPot / 2);
      setOutcome('TIE');
      setOutcomeMessage(`EMPATE! Ambas as mãos formaram ${pBest.name}. Pote dividido (+${split} fichas).`);
      onUpdateBalance(split, false, 'texas-holdem');
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fade-in pb-12">
      {/* Top Bar Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Lobby</span>
        </button>

        <button
          onClick={() => setShowHowToPlay(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
          <span>Como Jogar</span>
        </button>
      </div>

      {/* Main Poker Table */}
      <div className="casino-felt casino-wood-border rounded-2xl p-3.5 sm:p-5 min-h-[260px] sm:min-h-[290px] flex flex-col justify-between shadow-xl relative">
        {/* Pot and Stage Indicator */}
        <div className="flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase tracking-widest text-amber-400 font-cinzel font-bold">
              Hold&apos;em
            </span>
            <span className="text-[11px] text-slate-300">
              · {stage === 'BETTING' ? 'Ante Inicial' : stage === 'FLOP_ROUND' ? 'Flop' : stage === 'TURN_ROUND' ? 'Turn' : 'Showdown'}
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-0.5 rounded-lg border border-amber-500/30">
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Pote:</span>
            <span className="font-mono text-xs sm:text-sm font-bold text-amber-300 tabular-nums">
              {totalPot} fichas
            </span>
          </div>
        </div>

        {/* Dealer Hole Cards */}
        <div className="space-y-1 z-10">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-cinzel font-bold text-amber-300 uppercase tracking-wider">
              Casa (Dealer)
            </span>
            {stage === 'SHOWDOWN' && dealerHandResult && (
              <span className="text-[11px] font-mono font-bold text-amber-300 bg-slate-900/80 px-1.5 py-0.5 rounded border border-amber-500/30">
                {dealerHandResult.name}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {dealerCards.length === 0 ? (
              <div className="flex items-center gap-2">
                <PlayingCard hidden size="sm" />
                <PlayingCard hidden size="sm" />
              </div>
            ) : (
              dealerCards.map((c, i) => (
                <PlayingCard
                  key={c.id || i}
                  card={c}
                  hidden={stage !== 'SHOWDOWN'}
                  size="sm"
                />
              ))
            )}
          </div>
        </div>

        {/* 5 Community Cards Center Zone */}
        <div className="my-1.5 py-2 border-y border-amber-500/20 bg-slate-950/40 rounded-xl px-2 flex flex-col items-center justify-center z-10">
          <div className="flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap">
            {Array.from({ length: 5 }).map((_, idx) => {
              const card = communityCards[idx];
              const isRevealed = idx < revealedCommunityCount;
              return (
                <PlayingCard
                  key={idx}
                  card={card}
                  hidden={!isRevealed}
                  size="sm"
                />
              );
            })}
          </div>
        </div>

        {/* Player Hole Cards */}
        <div className="space-y-1 z-10">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-cinzel font-bold text-amber-300 uppercase tracking-wider">
              Suas Cartas
            </span>
            {stage === 'SHOWDOWN' && playerHandResult && (
              <span className="text-[11px] font-mono font-bold text-amber-300 bg-slate-900/80 px-1.5 py-0.5 rounded border border-amber-500/30">
                {playerHandResult.name}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {playerCards.length === 0 ? (
              <div className="flex items-center gap-2">
                <PlayingCard hidden size="sm" />
                <PlayingCard hidden size="sm" />
              </div>
            ) : (
              playerCards.map((c, i) => (
                <PlayingCard key={c.id || i} card={c} size="sm" />
              ))
            )}
          </div>
        </div>

        {/* Result Message Banner */}
        {outcomeMessage && (
          <div className="my-1 text-center animate-bounce z-20">
            <div
              className={`inline-block px-4 py-1.5 rounded-lg font-cinzel font-bold text-xs sm:text-sm border shadow-xl ${
                outcome === 'WIN'
                  ? 'bg-amber-500 text-slate-950 border-amber-300'
                  : outcome === 'TIE'
                  ? 'bg-slate-800 text-amber-300 border-amber-500/40'
                  : 'bg-slate-900 text-red-200 border-red-500/50'
              }`}
            >
              {outcomeMessage}
            </div>
          </div>
        )}
      </div>

      {/* Controls & Action Buttons */}
      <div className="space-y-2.5">
        {stage === 'BETTING' || stage === 'SHOWDOWN' ? (
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="flex-1">
              <ChipSelector
                currentBet={anteBet}
                balance={balance}
                onBetChange={setAnteBet}
                disabled={false}
              />
            </div>

            <button
              type="button"
              onClick={handleDealHand}
              disabled={anteBet <= 0 || anteBet > balance}
              className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-bold text-sm shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              {stage === 'SHOWDOWN' ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              <span>{stage === 'SHOWDOWN' ? 'Nova Mão' : 'Apostar Ante'}</span>
            </button>
          </div>
        ) : (
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-xl p-2.5 flex flex-wrap items-center justify-center gap-2.5 shadow-lg">
            {/* Pagar (Call) */}
            <button
              type="button"
              onClick={handleCall}
              className="flex-1 min-w-[110px] py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition-transform active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Pagar (Call)</span>
            </button>

            {/* Aumentar (Raise) */}
            <button
              type="button"
              onClick={handleRaise}
              disabled={balance < anteBet}
              className="flex-1 min-w-[110px] py-2 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition-transform active:scale-95 flex items-center justify-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Aumentar (+{anteBet})</span>
            </button>

            {/* Desistir (Fold) */}
            <button
              type="button"
              onClick={handleFold}
              className="flex-1 min-w-[110px] py-2 px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow transition-transform active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>Desistir (Fold)</span>
            </button>
          </div>
        )}
      </div>

      {/* Rules Modal */}
      <HowToPlayModal
        isOpen={showHowToPlay}
        onClose={() => setShowHowToPlay(false)}
        gameId="texas-holdem"
      />
    </div>
  );
};
