import React from 'react';
import { ShieldAlert, Award, HeartHandshake } from 'lucide-react';

interface FooterProps {
  onOpenSocialModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenSocialModal }) => {
  return (
    <footer className="mt-auto border-t border-amber-500/15 bg-[#050806] text-slate-400 py-8 px-4 sm:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Prominent Social Casino Legal Notice */}
        <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0 text-amber-400">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-sm text-slate-300 leading-relaxed flex-1">
            <strong className="text-amber-400 font-semibold block sm:inline">
              AVISO LEGAL DE CASSINO SOCIAL:
            </strong>{' '}
            Este site é uma plataforma de entretenimento com simulações de jogos de azar 100% gratuita. Todas as apostas e prêmios utilizam exclusivamente moedas virtuais fictícias (&quot;Fichas&quot;). Não há depósitos em dinheiro real, apostas reais, transações financeiras, prêmios monetários, pagamentos ou saques de qualquer espécie. O sucesso neste cassino social não implica sucesso futuro em apostas reais. Destinado exclusivamente para maiores de 18 anos.
          </div>
          <button
            onClick={onOpenSocialModal}
            className="text-xs text-amber-400 hover:text-amber-300 underline font-medium whitespace-nowrap cursor-pointer shrink-0"
          >
            Saber mais
          </button>
        </div>

        {/* Footer Meta & Disclaimer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 pt-2 border-t border-slate-800">
          <div className="flex items-center gap-3">
            <span className="font-cinzel text-amber-400/80 font-bold">IMPERIAL CASSINO SOCIAL</span>
            <span aria-hidden="true">·</span>
            <span>Sem Dinheiro Real</span>
            <span aria-hidden="true">·</span>
            <span>Versão 1.0</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-slate-400">
              <HeartHandshake className="w-3.5 h-3.5 text-emerald-400" /> Jogue por pura diversão
            </span>
            <span className="text-amber-500/80 font-semibold">+18</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
