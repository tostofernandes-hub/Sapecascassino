import React from 'react';
import { X, HelpCircle, BookOpen, CheckCircle2 } from 'lucide-react';
import { GameId } from '../types/casino';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
  gameId: GameId;
}

interface GameRuleData {
  title: string;
  subtitle: string;
  objective: string;
  steps: string[];
  payouts: { label: string; value: string }[];
  tips: string[];
}

const RULES: Record<string, GameRuleData> = {
  blackjack: {
    title: 'Blackjack (21)',
    subtitle: 'Derrote a mão do Dealer sem ultrapassar 21 pontos',
    objective: 'Obter uma pontuação mais próxima de 21 do que o Dealer sem ultrapassar 21.',
    steps: [
      'Você e o Dealer recebem 2 cartas (uma carta do dealer fica oculta).',
      'Ás vale 1 ou 11 pontos; cartas 10, J, Q e K valem 10 pontos; números de 2 a 9 mantêm seu valor.',
      'Clique em "Pedir Carta (Hit)" para receber mais cartas até estar satisfeito.',
      'Clique em "Parar (Stand)" para encerrar sua vez e passar a rodada para o Dealer.',
      'Se suas duas primeiras cartas somarem um bom total e tiver saldo, você pode "Dobrar (Double Down)" para dobrar a aposta e receber apenas mais uma carta.',
      'O Dealer é obrigado a comprar cartas até atingir pelo menos 17 pontos.'
    ],
    payouts: [
      { label: 'Blackjack Natural (21 com 2 cartas)', value: '3 : 2 (1,5x o lucro)' },
      { label: 'Vitória Comum (Pontuação maior que a do Dealer)', value: '1 : 1' },
      { label: 'Empate (Push)', value: 'Aposta devolvida' },
      { label: 'Estourar (Bust > 21)', value: 'Perde a aposta' }
    ],
    tips: [
      'Pare sempre que tiver 17 ou mais para evitar estourar.',
      'Se o Dealer mostrar uma carta fraca (4, 5 ou 6), seja mais conservador pois a chance dele estourar é alta.'
    ]
  },
  'texas-holdem': {
    title: "Pôquer Texas Hold'em",
    subtitle: 'Enfrente a casa no jogo de pôquer mais famoso do mundo',
    objective: 'Formar a melhor combinação de 5 cartas usando suas 2 cartas fechadas e as 5 cartas comunitárias da mesa.',
    steps: [
      'Faça sua aposta Ante inicial para receber 2 cartas fechadas e a casa também recebe 2 cartas ocultas.',
      'A mesa revela as 3 primeiras cartas comunitárias (o Flop). Você pode Pagar (Call) para continuar ou Aumentar (Raise) ou Desistir (Fold).',
      'Em seguida a mesa revela a 4ª carta (o Turn). Você decide novamente suas ações.',
      'A 5ª e última carta (o River) é revelada.',
      'No Showdown final, as cartas da casa são reveladas. O sistema compara a melhor mão de 5 cartas de cada lado.'
    ],
    payouts: [
      { label: 'Royal Flush', value: '100 : 1' },
      { label: 'Straight Flush', value: '40 : 1' },
      { label: 'Quadra (Four of a Kind)', value: '20 : 1' },
      { label: 'Full House', value: '7 : 1' },
      { label: 'Flush (Cor)', value: '5 : 1' },
      { label: 'Straight (Sequência)', value: '4 : 1' },
      { label: 'Trinca / Dois Pares / Um Par / Carta Alta', value: '1 : 1' }
    ],
    tips: [
      'Pares altos (A-A, K-K, Q-Q) e conectores do mesmo naipe (A-K, K-Q suited) têm grande potencial.',
      'Observe a textura das cartas comunitárias antes de aumentar.'
    ]
  },
  roulette: {
    title: 'Roleta Europeia',
    subtitle: 'Roda numerada de 0 a 36 com múltiplas opções de aposta',
    objective: 'Prever em qual número ou grupo de números a bola da roleta vai pousar.',
    steps: [
      'Escolha o valor da sua ficha e clique nos setores da mesa para posicionar suas apostas.',
      'Você pode apostar em números individuais (0 a 36) ou apostas externas (Cores, Par/Ímpar, Dúzias, etc.).',
      'Clique em "Girar Roleta" para iniciar a roda e acompanhar a desaceleração da esfera.',
      'O número sorteado é destacado e todos os pagamentos vencedores são creditados no seu saldo.'
    ],
    payouts: [
      { label: 'Número Pleno (0 a 36)', value: '35 : 1' },
      { label: 'Dúzias (1-12, 13-24, 25-36)', value: '2 : 1' },
      { label: 'Vermelho / Preto', value: '1 : 1' },
      { label: 'Par / Ímpar', value: '1 : 1' },
      { label: 'Baixo (1-18) / Alto (19-36)', value: '1 : 1' }
    ],
    tips: [
      'O número 0 é verde e não é nem par nem ímpar, nem alto nem baixo, nem vermelho nem preto.',
      'Apostas externas (como Vermelho ou Par) oferecem quase 50% de chance de vitória.'
    ]
  },
  'video-poker': {
    title: 'Vídeo Pôquer (Jacks or Better)',
    subtitle: 'Estratégia de 5 cartas com trocas e tabela de multiplicadores',
    objective: 'Obter uma mão final de 5 cartas de valor igual ou superior a um Par de Valetes.',
    steps: [
      'Defina o valor da aposta e clique em "Distribuir 5 Cartas".',
      'Analise sua mão e clique nas cartas que deseja MANTER (elas recebem a marcação MANTER).',
      'Clique em "Trocar e Avaliar Mão" para descartar as cartas restantes e receber substitutas.',
      'Sua mão final é classificada e os prêmios são pagos de acordo com a tabela exibida no topo.'
    ],
    payouts: [
      { label: 'Royal Flush (10, J, Q, K, A do mesmo naipe)', value: '250x' },
      { label: 'Straight Flush (Sequência do mesmo naipe)', value: '50x' },
      { label: 'Quadra (4 cartas iguais)', value: '25x' },
      { label: 'Full House (Trinca + Par)', value: '9x' },
      { label: 'Flush (5 cartas do mesmo naipe)', value: '6x' },
      { label: 'Sequência (5 números consecutivos)', value: '4x' },
      { label: 'Trinca (3 cartas iguais)', value: '3x' },
      { label: 'Dois Pares distintos', value: '2x' },
      { label: 'Par de Valetes, Damas, Reis ou Áses', value: '1x (Devolve aposta)' }
    ],
    tips: [
      'Pares baixos (ex: 2 a 10) não pagam sozinhos, mas vale a pena mantê-los para tentar trinca ou dois pares.',
      'Se receber 4 cartas para um flush ou straight aberto, mantenha-as para tentar completar a sequência.'
    ]
  },
  baccarat: {
    title: 'Bacarate (Punto Banco)',
    subtitle: 'O elegante duelo entre a mão do Jogador e da Banca',
    objective: 'Apostar em qual dos dois lados (Jogador ou Banca) terminará com a pontuação mais próxima de 9, ou se haverá Empate.',
    steps: [
      'Escolha se deseja apostar no Jogador (Player), na Banca (Banker) ou no Empate (Tie).',
      'São distribuídas 2 cartas para cada lado.',
      'Pontuação: Ás vale 1 ponto; 10, J, Q e K valem 0 pontos; números de 2 a 9 mantêm seu valor. A soma é sempre calculada no módulo 10 (ex: 7 + 8 = 15 -> vale 5 pontos).',
      'Se qualquer lado somar 8 ou 9 com as duas primeiras cartas, é um "Natural" e a mão encerra.',
      'Caso contrário, as regras tradicionais da 3ª carta determinam se Jogador ou Banca compram mais uma carta.'
    ],
    payouts: [
      { label: 'Jogador (Player)', value: '1 : 1' },
      { label: 'Banca (Banker)', value: '0,95 : 1 (comissão de 5%)' },
      { label: 'Empate (Tie)', value: '8 : 1' }
    ],
    tips: [
      'Estatisticamente, a aposta na Banca possui a menor margem da casa no cassino.',
      'Se der Empate e você tiver apostado no Jogador ou na Banca, sua aposta é devolvida integralmente!'
    ]
  },
  slots: {
    title: 'Caça-Níquel Fortune (Tigrinho)',
    subtitle: 'Bobinas 3x3 com temas dinâmicos e multiplicadores nas linhas',
    objective: 'Alinhar 3 símbolos idênticos em qualquer uma das 5 linhas de pagamento.',
    steps: [
      'Escolha o valor da aposta usando o seletor de fichas.',
      'A cada giro, você pode jogar com temas aleatórios (Tigrinho, Frutas 777, Egito, Espaço, Oceano) ou escolher seu tema favorito no botão de alternância.',
      'Clique em "Girar Caça-Níquel" para acionar as bobinas com efeito de blur e parada sequencial.',
      'As 5 linhas válidas são: 3 linhas horizontais e 2 diagonais.',
      'Linhas vencedoras piscam e multiplicam o valor da aposta conforme a raridade do símbolo.'
    ],
    payouts: [
      { label: 'Símbolo Principal / Jackpot (ex: Tigre Dourado, 777, Faraó)', value: '50x por linha' },
      { label: 'Símbolo Nível 2 (ex: Dragão, Diamante, Olho de Hórus)', value: '25x' },
      { label: 'Símbolo Nível 3 (ex: Sapo da Fortuna, Sino, Escaravelho)', value: '15x' },
      { label: 'Símbolo Nível 4 (ex: Moeda de Ouro, Melancia, Pirâmide)', value: '10x' },
      { label: 'Símbolo Nível 5 (ex: Panda, Uva, Anúbis)', value: '5x' },
      { label: 'Símbolo Nível 6 (ex: Bambu, Cereja, Ânfora)', value: '3x' }
    ],
    tips: [
      'Como são 5 linhas de pagamento, você pode acertar múltiplas linhas no mesmo giro e somar todos os multiplicadores!'
    ]
  },
  lottery: {
    title: 'Loteria Mega Imperial',
    subtitle: 'Sorteio de 6 dezenas no estilo Mega-Sena',
    objective: 'Escolher entre 6 e 15 números no volante de 1 a 60 e acertar 4, 5 ou 6 dezenas sorteadas.',
    steps: [
      'Clique nos números de 1 a 60 no volante para montar seu jogo (mínimo de 6 e máximo de 15 números).',
      'Ou use o botão "Surpresinha" para que o sistema escolha 6 números aleatórios instantaneamente.',
      'Defina o valor base da sua aposta. Apostas com mais de 6 números têm seu custo calculado proporcionalmente às combinações possíveis.',
      'Clique em "Apostar e Sortear" para acompanhar a revelação emocionante das 6 bolas que saem do globo.',
      'Os acertos são comparados e destacados na tela.'
    ],
    payouts: [
      { label: 'Sena (6 acertos)', value: '50.000x a aposta base' },
      { label: 'Quina (5 acertos)', value: '1.500x a aposta base' },
      { label: 'Quadra (4 acertos)', value: '50x a aposta base' },
      { label: 'Menos de 4 acertos', value: 'Sem premiação' }
    ],
    tips: [
      'Jogar mais números aumenta substancialmente as chances estatísticas de pontuar nas faixas de Quadra e Quina.'
    ]
  }
};

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({
  isOpen,
  onClose,
  gameId
}) => {
  if (!isOpen) return null;

  const data = RULES[gameId] || RULES.blackjack;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0e1713] border border-amber-500/40 rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-amber-500/20 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-cinzel text-lg sm:text-xl font-bold text-amber-300 leading-tight">
                Como Jogar: {data.title}
              </h3>
              <p className="text-xs text-slate-400">
                {data.subtitle}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800/60 transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm text-slate-300 leading-relaxed">
          {/* Objective */}
          <div>
            <h4 className="font-cinzel font-bold text-amber-400 text-xs uppercase tracking-wider mb-1.5">
              Objetivo
            </h4>
            <p className="bg-slate-900/60 border border-slate-800 rounded-lg p-3 text-slate-200">
              {data.objective}
            </p>
          </div>

          {/* Steps */}
          <div>
            <h4 className="font-cinzel font-bold text-amber-400 text-xs uppercase tracking-wider mb-2">
              Regras e Passo a Passo
            </h4>
            <ul className="space-y-2">
              {data.steps.map((step, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Payouts */}
          <div>
            <h4 className="font-cinzel font-bold text-amber-400 text-xs uppercase tracking-wider mb-2">
              Tabela de Pagamentos
            </h4>
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-800/80 text-xs">
              {data.payouts.map((p, idx) => (
                <div key={idx} className="flex items-center justify-between p-2.5">
                  <span className="text-slate-300 font-medium">{p.label}</span>
                  <span className="font-mono font-bold text-amber-400 text-right">{p.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tips */}
          {data.tips.length > 0 && (
            <div>
              <h4 className="font-cinzel font-bold text-amber-400 text-xs uppercase tracking-wider mb-1.5">
                Dicas de Jogo
              </h4>
              <ul className="list-disc list-inside space-y-1 text-xs text-slate-400">
                {data.tips.map((tip, idx) => (
                  <li key={idx}>{tip}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-amber-500/20 bg-slate-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider shadow transition-all cursor-pointer"
          >
            Entendido, Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
