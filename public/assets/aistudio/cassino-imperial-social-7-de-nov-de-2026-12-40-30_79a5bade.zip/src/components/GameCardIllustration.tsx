import React from 'react';
import { GameId } from '../types/casino';

interface GameCardIllustrationProps {
  gameId: GameId;
  className?: string;
}

export const GameCardIllustration: React.FC<GameCardIllustrationProps> = ({
  gameId,
  className = ''
}) => {
  return (
    <div className={`relative w-full aspect-[16/9] overflow-hidden rounded-xl bg-slate-950 select-none ${className}`}>
      {/* Background Gradients & Textures */}
      {gameId === 'blackjack' && (
        <svg viewBox="0 0 400 225" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="felt-bj" cx="50%" cy="40%" r="60%">
              <stop offset="0%" stopColor="#14532d" />
              <stop offset="60%" stopColor="#052e16" />
              <stop offset="100%" stopColor="#021a0d" />
            </radialGradient>
            <linearGradient id="gold-metal" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#eab308" />
              <stop offset="100%" stopColor="#854d0e" />
            </linearGradient>
            <filter id="shadow-card" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="2" dy="8" stdDeviation="6" floodColor="#000000" floodOpacity="0.7" />
            </filter>
          </defs>
          {/* Table Felt */}
          <rect width="400" height="225" fill="url(#felt-bj)" />
          <path d="M 40 225 A 220 120 0 0 1 360 225" stroke="#f59e0b" strokeWidth="2" strokeDasharray="6 6" fill="none" opacity="0.4" />
          <text x="200" y="70" fill="#f59e0b" fontSize="11" fontWeight="bold" letterSpacing="3" textAnchor="middle" opacity="0.5" fontFamily="serif">
            BLACKJACK PAGA 3 A 2
          </text>
          
          {/* Stack of Chips */}
          <g transform="translate(90, 140)">
            <ellipse cx="0" cy="18" rx="28" ry="12" fill="#7f1d1d" stroke="#f87171" strokeWidth="1.5" />
            <ellipse cx="0" cy="12" rx="28" ry="12" fill="#991b1b" stroke="#f87171" strokeWidth="1.5" />
            <ellipse cx="0" cy="6" rx="28" ry="12" fill="#b91c1c" stroke="#f87171" strokeWidth="1.5" />
            <ellipse cx="0" cy="0" rx="28" ry="12" fill="#dc2626" stroke="#fecaca" strokeWidth="2" />
            <circle cx="0" cy="0" r="14" fill="#7f1d1d" stroke="#fca5a5" strokeWidth="1" strokeDasharray="3 3" />
            <text x="0" y="4" fill="#ffffff" fontSize="10" fontWeight="bold" textAnchor="middle">100</text>
          </g>

          {/* Fanned Cards: Ace of Spades & Jack of Clubs */}
          <g transform="translate(210, 125) rotate(-14)" filter="url(#shadow-card)">
            <rect x="-42" y="-62" width="84" height="124" rx="6" fill="#ffffff" stroke="#e2e8f0" strokeWidth="2" />
            <text x="-32" y="-42" fill="#0f172a" fontSize="16" fontWeight="bold" fontFamily="sans-serif">A</text>
            <text x="-32" y="-28" fill="#0f172a" fontSize="13">♠</text>
            <text x="0" y="10" fill="#0f172a" fontSize="36" textAnchor="middle">♠</text>
          </g>

          <g transform="translate(255, 120) rotate(12)" filter="url(#shadow-card)">
            <rect x="-42" y="-62" width="84" height="124" rx="6" fill="#ffffff" stroke="#e2e8f0" strokeWidth="2" />
            <text x="-32" y="-42" fill="#0f172a" fontSize="16" fontWeight="bold" fontFamily="sans-serif">J</text>
            <text x="-32" y="-28" fill="#0f172a" fontSize="13">♣</text>
            <text x="0" y="10" fill="#0f172a" fontSize="36" textAnchor="middle">♣</text>
            <text x="0" y="38" fill="#d97706" fontSize="9" fontWeight="bold" textAnchor="middle" fontFamily="serif">VALETE</text>
          </g>
        </svg>
      )}

      {gameId === 'roulette' && (
        <svg viewBox="0 0 400 225" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="felt-roul" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="100%" stopColor="#090d16" />
            </radialGradient>
            <linearGradient id="gold-rim" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#d97706" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>
            <filter id="roulette-glow">
              <feDropShadow dx="0" dy="0" stdDeviation="8" floodColor="#f59e0b" floodOpacity="0.5" />
            </filter>
          </defs>
          <rect width="400" height="225" fill="url(#felt-roul)" />

          {/* Half Roulette Wheel Isometric / Top-Down */}
          <g transform="translate(200, 150)">
            <circle cx="0" cy="0" r="115" fill="#2e1005" stroke="url(#gold-rim)" strokeWidth="6" filter="url(#roulette-glow)" />
            <circle cx="0" cy="0" r="95" fill="#0f172a" stroke="#78350f" strokeWidth="2" />

            {/* Alternating Pockets */}
            {Array.from({ length: 24 }).map((_, i) => {
              const ang = (360 / 24) * i;
              const col = i === 0 ? '#059669' : i % 2 === 0 ? '#dc2626' : '#0f172a';
              return (
                <path
                  key={i}
                  d={`M 0 0 L ${95 * Math.cos((ang - 7.5) * Math.PI / 180)} ${95 * Math.sin((ang - 7.5) * Math.PI / 180)} A 95 95 0 0 1 ${95 * Math.cos((ang + 7.5) * Math.PI / 180)} ${95 * Math.sin((ang + 7.5) * Math.PI / 180)} Z`}
                  fill={col}
                  stroke="#b45309"
                  strokeWidth="0.5"
                />
              );
            })}

            {/* Brass Hub Turret */}
            <circle cx="0" cy="0" r="44" fill="#451a03" stroke="url(#gold-rim)" strokeWidth="3" />
            <circle cx="0" cy="0" r="18" fill="#d97706" />
            <circle cx="0" cy="0" r="8" fill="#fef08a" />

            {/* Ball */}
            <circle cx="68" cy="-35" r="7" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" filter="url(#roulette-glow)" />
          </g>

          <text x="200" y="32" fill="#fbbf24" fontSize="13" fontWeight="bold" letterSpacing="4" textAnchor="middle" fontFamily="serif">
            ROLETA EUROPEIA 0-36
          </text>
        </svg>
      )}

      {gameId === 'texas-holdem' && (
        <svg viewBox="0 0 400 225" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="felt-th" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#1e1b4b" />
              <stop offset="70%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#050814" />
            </radialGradient>
          </defs>
          <rect width="400" height="225" fill="url(#felt-th)" />

          {/* Oval Table outline */}
          <ellipse cx="200" cy="112" rx="175" ry="90" fill="none" stroke="#6366f1" strokeWidth="2" strokeDasharray="4 6" opacity="0.3" />

          {/* Community cards preview (3 mini cards) */}
          <g transform="translate(140, 75)">
            <rect x="-18" y="-26" width="36" height="52" rx="4" fill="#ffffff" stroke="#cbd5e1" />
            <text x="0" y="2" fill="#dc2626" fontSize="14" textAnchor="middle">♥</text>
          </g>
          <g transform="translate(200, 75)">
            <rect x="-18" y="-26" width="36" height="52" rx="4" fill="#ffffff" stroke="#cbd5e1" />
            <text x="0" y="2" fill="#0f172a" fontSize="14" textAnchor="middle">♠</text>
          </g>
          <g transform="translate(260, 75)">
            <rect x="-18" y="-26" width="36" height="52" rx="4" fill="#ffffff" stroke="#cbd5e1" />
            <text x="0" y="2" fill="#dc2626" fontSize="14" textAnchor="middle">♦</text>
          </g>

          {/* Player Pocket Rockets (A-A or A-K) */}
          <g transform="translate(180, 160) rotate(-10)">
            <rect x="-32" y="-48" width="64" height="96" rx="5" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
            <text x="-24" y="-32" fill="#dc2626" fontSize="13" fontWeight="bold">A</text>
            <text x="-24" y="-20" fill="#dc2626" fontSize="11">♥</text>
            <text x="0" y="10" fill="#dc2626" fontSize="28" textAnchor="middle">♥</text>
          </g>
          <g transform="translate(225, 155) rotate(12)">
            <rect x="-32" y="-48" width="64" height="96" rx="5" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
            <text x="-24" y="-32" fill="#0f172a" fontSize="13" fontWeight="bold">K</text>
            <text x="-24" y="-20" fill="#0f172a" fontSize="11">♠</text>
            <text x="0" y="10" fill="#0f172a" fontSize="28" textAnchor="middle">♠</text>
          </g>

          <text x="200" y="28" fill="#a5b4fc" fontSize="11" fontWeight="bold" letterSpacing="3" textAnchor="middle" fontFamily="serif">
            TEXAS HOLD&apos;EM · FLOP · TURN · RIVER
          </text>
        </svg>
      )}

      {gameId === 'video-poker' && (
        <svg viewBox="0 0 400 225" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="vp-bg" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#172554" />
              <stop offset="100%" stopColor="#080f20" />
            </linearGradient>
          </defs>
          <rect width="400" height="225" fill="url(#vp-bg)" />

          {/* 5 Card Royal Flush Fan */}
          {['10', 'J', 'Q', 'K', 'A'].map((label, idx) => {
            const rot = (idx - 2) * 8;
            const xOffset = 200 + (idx - 2) * 55;
            return (
              <g key={label} transform={`translate(${xOffset}, 130) rotate(${rot})`}>
                <rect x="-26" y="-42" width="52" height="84" rx="5" fill="#ffffff" stroke="#f59e0b" strokeWidth="1.5" />
                <text x="-19" y="-26" fill="#dc2626" fontSize="12" fontWeight="bold">{label}</text>
                <text x="-19" y="-14" fill="#dc2626" fontSize="10">♥</text>
                <text x="0" y="12" fill="#dc2626" fontSize="24" textAnchor="middle">♥</text>
              </g>
            );
          })}

          {/* Jacks or Better Banner */}
          <rect x="70" y="18" width="260" height="28" rx="6" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
          <text x="200" y="37" fill="#38bdf8" fontSize="12" fontWeight="bold" letterSpacing="3" textAnchor="middle" fontFamily="sans-serif">
            JACKS OR BETTER · 250X
          </text>
        </svg>
      )}

      {gameId === 'baccarat' && (
        <svg viewBox="0 0 400 225" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="felt-bac" cx="50%" cy="40%" r="60%">
              <stop offset="0%" stopColor="#3f2305" />
              <stop offset="80%" stopColor="#1c0f03" />
              <stop offset="100%" stopColor="#090501" />
            </radialGradient>
          </defs>
          <rect width="400" height="225" fill="url(#felt-bac)" />

          {/* Golden Crown */}
          <g transform="translate(200, 50) scale(0.8)">
            <path d="M -30 20 L -40 -15 L -15 0 L 0 -25 L 15 0 L 40 -15 L 30 20 Z" fill="#eab308" stroke="#fef08a" strokeWidth="2" />
            <circle cx="0" cy="-25" r="4" fill="#ef4444" />
            <circle cx="-40" cy="-15" r="3" fill="#3b82f6" />
            <circle cx="40" cy="-15" r="3" fill="#3b82f6" />
          </g>

          {/* Player side & Banker side cards */}
          <g transform="translate(130, 140)">
            <rect x="-30" y="-45" width="60" height="90" rx="5" fill="#ffffff" stroke="#60a5fa" strokeWidth="2" />
            <text x="0" y="-15" fill="#2563eb" fontSize="11" fontWeight="bold" textAnchor="middle">PLAYER</text>
            <text x="0" y="20" fill="#2563eb" fontSize="32" fontWeight="bold" textAnchor="middle">9</text>
          </g>

          <g transform="translate(270, 140)">
            <rect x="-30" y="-45" width="60" height="90" rx="5" fill="#ffffff" stroke="#f87171" strokeWidth="2" />
            <text x="0" y="-15" fill="#dc2626" fontSize="11" fontWeight="bold" textAnchor="middle">BANKER</text>
            <text x="0" y="20" fill="#dc2626" fontSize="32" fontWeight="bold" textAnchor="middle">8</text>
          </g>

          <text x="200" y="145" fill="#f59e0b" fontSize="16" fontWeight="bold" textAnchor="middle">VS</text>
        </svg>
      )}

      {gameId === 'slots' && (
        <svg viewBox="0 0 400 225" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="slots-bg" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#450a0a" />
              <stop offset="50%" stopColor="#2e0505" />
              <stop offset="100%" stopColor="#110202" />
            </linearGradient>
            <linearGradient id="gold-frame" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>
          </defs>
          <rect width="400" height="225" fill="url(#slots-bg)" />

          {/* Golden Slot Reels Window */}
          <rect x="70" y="35" width="260" height="150" rx="12" fill="#090d0b" stroke="url(#gold-frame)" strokeWidth="4" />

          {/* 3 Columns */}
          <rect x="85" y="45" width="70" height="130" rx="6" fill="#141e17" stroke="#374151" />
          <rect x="165" y="45" width="70" height="130" rx="6" fill="#141e17" stroke="#f59e0b" strokeWidth="2" />
          <rect x="245" y="45" width="70" height="130" rx="6" fill="#141e17" stroke="#374151" />

          {/* Symbols */}
          <text x="120" y="125" fontSize="38" textAnchor="middle">🐯</text>
          <text x="200" y="125" fontSize="46" textAnchor="middle">🐯</text>
          <text x="280" y="125" fontSize="38" textAnchor="middle">🐯</text>

          {/* Golden Horizontal Payline through center */}
          <line x1="75" y1="112" x2="325" y2="112" stroke="#fef08a" strokeWidth="3" strokeDasharray="5 3" />

          <text x="200" y="25" fill="#fef08a" fontSize="12" fontWeight="bold" letterSpacing="3" textAnchor="middle" fontFamily="serif">
            FORTUNE TIGRINHO · 100X
          </text>
        </svg>
      )}

      {gameId === 'lottery' && (
        <svg viewBox="0 0 400 225" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="lot-bg" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#064e3b" />
              <stop offset="100%" stopColor="#021c14" />
            </radialGradient>
            <radialGradient id="sphere-glass" cx="35%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4" />
              <stop offset="60%" stopColor="#10b981" stopOpacity="0.1" />
              <stop offset="100%" stopColor="#064e3b" stopOpacity="0.8" />
            </radialGradient>
          </defs>
          <rect width="400" height="225" fill="url(#lot-bg)" />

          {/* Golden Lottery Cage Ring */}
          <circle cx="200" cy="115" r="75" fill="none" stroke="#f59e0b" strokeWidth="3" opacity="0.6" />
          <ellipse cx="200" cy="115" rx="75" ry="30" fill="none" stroke="#f59e0b" strokeWidth="2" opacity="0.4" />

          {/* Bouncing Lottery Balls */}
          <g transform="translate(160, 95)">
            <circle cx="0" cy="0" r="18" fill="#10b981" stroke="#34d399" strokeWidth="2" />
            <text x="0" y="5" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">07</text>
          </g>
          <g transform="translate(205, 80)">
            <circle cx="0" cy="0" r="19" fill="#f59e0b" stroke="#fef08a" strokeWidth="2" />
            <text x="0" y="5" fill="#0f172a" fontSize="12" fontWeight="black" textAnchor="middle">14</text>
          </g>
          <g transform="translate(235, 115)">
            <circle cx="0" cy="0" r="18" fill="#10b981" stroke="#34d399" strokeWidth="2" />
            <text x="0" y="5" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">21</text>
          </g>
          <g transform="translate(175, 135)">
            <circle cx="0" cy="0" r="20" fill="#f59e0b" stroke="#fef08a" strokeWidth="2" />
            <text x="0" y="6" fill="#0f172a" fontSize="13" fontWeight="black" textAnchor="middle">42</text>
          </g>

          <text x="200" y="28" fill="#a7f3d0" fontSize="11" fontWeight="bold" letterSpacing="3" textAnchor="middle" fontFamily="serif">
            LOTERIA MEGA · 6 DEZENAS
          </text>
        </svg>
      )}

      {/* Subtle Dark Vignette & Shine */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />
      <div className="absolute inset-0 bg-amber-400/0 group-hover:bg-amber-400/10 transition-colors duration-300 pointer-events-none" />
    </div>
  );
};
