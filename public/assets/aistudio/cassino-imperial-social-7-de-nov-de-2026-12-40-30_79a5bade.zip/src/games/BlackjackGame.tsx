import React, { useState } from 'react';
import { Card } from '../types/casino';
import { createDeck, shuffleDeck, calculateBlackjackScore } from '../utils/cards';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { PlayingCard } from '../components/PlayingCard';
import { ChipSelector } from '../components/ChipSelector';
import { HowToPlayModal } from '../components/HowToPlayModal';
import { ArrowLeft, Play, Hand, Plus, RotateCcw, HelpCircle } from 'lucide-react';

interface BlackjackGameProps {
  balance: number;
  onUpdateBalance: (delta: number, isWin: boolean, gameId: 'blackjack', betAmount?: number) => void;
  onBackToLobby: () => void;
}

type RoundStatus = 'BETTING' | 'PLAYER_TURN' | 'DEALER_TURN' | 'ENDED';

export const BlackjackGame: React.FC<BlackjackGameProps> = ({
  balance,
  onUpdateBalance,
  onBackToLobby
}) => {
  const [bet, setBet] = useState<number>(50);
  const [status, setStatus] = useState<RoundStatus>('BETTING');
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [resultMessage, setResultMessage] = useState<string>('');
  const [resultOutcome, setResultOutcome] = useState<'WIN' | 'LOSS' | 'PUSH' | 'BLACKJACK' | null>(null);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  // Start new round dealing initial cards
  const startRound = () => {
    if (bet <= 0 || bet > balance) return;

    soundManager.playShuffle();

    // Deduct initial bet
    onUpdateBalance(-bet, false, 'blackjack');

    // Shuffle fresh deck
    const newDeck = shuffleDeck(createDeck());
    const pCard1 = newDeck.pop()!;
    const dCard1 = newDeck.pop()!;
    const pCard2 = newDeck.pop()!;
    const dCard2 = newDeck.pop()!;

    const initialPlayer = [pCard1, pCard2];
    const initialDealer = [dCard1, dCard2];

    setPlayerHand(initialPlayer);
    setDealerHand(initialDealer);
    setDeck(newDeck);
    setResultOutcome(null);
    setResultMessage('');

    // Check immediate blackjacks
    const playerScore = calculateBlackjackScore(initialPlayer);
    const dealerScore = calculateBlackjackScore(initialDealer);

    if (playerScore.isBlackjack) {
      if (dealerScore.isBlackjack) {
        // Both blackjack -> push
        setStatus('ENDED');
        setResultOutcome('PUSH');
        setResultMessage('Ambos têm Blackjack! Empate (Push).');
        soundManager.playLoss();
        onUpdateBalance(bet, false, 'blackjack'); // Refund
      } else {
        // Player natural blackjack pays 3:2 (return bet + 1.5 * bet)
        setStatus('ENDED');
        setResultOutcome('BLACKJACK');
        const payout = Math.floor(bet * 2.5);
        setResultMessage(`BLACKJACK NATURAL! Você ganhou ${payout} fichas!`);
        soundManager.playJackpot();
        fireConfetti(3000);
        onUpdateBalance(payout, true, 'blackjack');
      }
    } else {
      setStatus('PLAYER_TURN');
      soundManager.playCardDeal();
    }
  };

  // Player hits
  const handleHit = () => {
    if (status !== 'PLAYER_TURN' || deck.length === 0) return;

    soundManager.playCardDeal();
    const newDeck = [...deck];
    const newCard = newDeck.pop()!;
    const newHand = [...playerHand, newCard];

    setPlayerHand(newHand);
    setDeck(newDeck);

    const score = calculateBlackjackScore(newHand);
    if (score.isBust) {
      // Player busts
      setStatus('ENDED');
      setResultOutcome('LOSS');
      setResultMessage(`Estourou com ${score.score}! O Dealer vence.`);
      soundManager.playLoss();
    } else if (score.score === 21) {
      // Auto stand on 21
      handleStand(newHand, newDeck);
    }
  };

  // Player doubles down
  const handleDoubleDown = () => {
    if (status !== 'PLAYER_TURN' || playerHand.length !== 2 || balance < bet) return;

    // Deduct additional bet
    onUpdateBalance(-bet, false, 'blackjack');
    const doubledBet = bet * 2;
    setBet(doubledBet);

    soundManager.playCardDeal();
    const newDeck = [...deck];
    const newCard = newDeck.pop()!;
    const newHand = [...playerHand, newCard];
    setPlayerHand(newHand);
    setDeck(newDeck);

    const score = calculateBlackjackScore(newHand);
    if (score.isBust) {
      setStatus('ENDED');
      setResultOutcome('LOSS');
      setResultMessage(`Estourou com ${score.score} no Dobro!`);
      soundManager.playLoss();
    } else {
      // Deal to dealer immediately
      handleStand(newHand, newDeck, doubledBet);
    }
  };

  // Player stands -> Dealer plays
  const handleStand = (
    currentPlayerHand = playerHand,
    currentDeck = deck,
    currentBetValue = bet
  ) => {
    setStatus('DEALER_TURN');
    soundManager.playCardDeal();

    let dHand = [...dealerHand];
    let dDeck = [...currentDeck];
    let dScore = calculateBlackjackScore(dHand);

    // Dealer draws until score is at least 17
    while (dScore.score < 17 && dDeck.length > 0) {
      const nextCard = dDeck.pop()!;
      dHand.push(nextCard);
      dScore = calculateBlackjackScore(dHand);
    }

    setDealerHand(dHand);
    setDeck(dDeck);
    setStatus('ENDED');

    const pScore = calculateBlackjackScore(currentPlayerHand);

    if (dScore.isBust) {
      // Dealer busts -> player wins 1:1 (bet + profit)
      setResultOutcome('WIN');
      setResultMessage(`Dealer estourou com ${dScore.score}! Você venceu!`);
      soundManager.playWin();
      fireConfetti(2000);
      onUpdateBalance(currentBetValue * 2, true, 'blackjack');
    } else if (pScore.score > dScore.score) {
      // Player has higher score
      setResultOutcome('WIN');
      setResultMessage(`Você venceu! (${pScore.score} vs ${dScore.score} do Dealer)`);
      soundManager.playWin();
      fireConfetti(2000);
      onUpdateBalance(currentBetValue * 2, true, 'blackjack');
    } else if (pScore.score < dScore.score) {
      // Dealer has higher score
      setResultOutcome('LOSS');
      setResultMessage(`Dealer venceu (${dScore.score} vs ${pScore.score}).`);
      soundManager.playLoss();
    } else {
      // Push -> return original bet
      setResultOutcome('PUSH');
      setResultMessage(`Empate em ${pScore.score} pontos! Fichas devolvidas.`);
      soundManager.playLoss();
      onUpdateBalance(currentBetValue, false, 'blackjack');
    }
  };

  const playerScore = calculateBlackjackScore(playerHand);
  const dealerScore = calculateBlackjackScore(dealerHand);
  const hideDealerHole = status === 'PLAYER_TURN';

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fade-in pb-10">
      {/* Top Header Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Lobby</span>
        </button>

        <button
          onClick={() => setShowHowToPlay(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
          <span>Como Jogar</span>
        </button>
      </div>

      {/* Blackjack Table Felt */}
      <div className="casino-felt casino-wood-border rounded-2xl p-4 sm:p-5 min-h-[270px] sm:min-h-[300px] flex flex-col justify-between relative shadow-xl overflow-hidden">
        {/* Table Felt Decorative Markings */}
        <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 border border-dashed border-amber-400/15 rounded-full h-44 pointer-events-none flex items-center justify-center">
          <span className="text-amber-400/10 font-cinzel text-xl sm:text-2xl font-black uppercase tracking-widest select-none">
            Blackjack Imperial
          </span>
        </div>

        {/* Dealer Zone */}
        <div className="relative z-10 space-y-1.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-cinzel font-bold tracking-widest text-amber-300 uppercase">
                Dealer
              </span>
              {dealerHand.length > 0 && !hideDealerHole && (
                <span className="bg-slate-900/80 border border-amber-500/30 px-1.5 py-0.5 rounded text-[11px] font-mono font-bold text-amber-300">
                  {dealerScore.score} {dealerScore.isBust ? '(Bust)' : ''}
                </span>
              )}
            </div>
            {hideDealerHole && dealerHand.length > 0 && (
              <span className="text-[11px] text-slate-300 italic">
                Visível: {dealerHand[0]?.label}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 min-h-[96px] flex-wrap">
            {dealerHand.length === 0 ? (
              <div className="w-16 h-22 rounded border border-dashed border-amber-400/20 flex items-center justify-center text-[10px] text-amber-400/40">
                Dealer
              </div>
            ) : (
              dealerHand.map((card, idx) => (
                <PlayingCard
                  key={card.id || idx}
                  card={card}
                  hidden={idx === 1 && hideDealerHole}
                  size="sm"
                />
              ))
            )}
          </div>
        </div>

        {/* Center Result Message Alert */}
        {resultMessage && (
          <div className="relative z-20 my-1 text-center animate-bounce">
            <div
              className={`inline-block px-4 py-1.5 rounded-lg shadow-xl font-bold font-cinzel text-xs sm:text-sm border ${
                resultOutcome === 'BLACKJACK' || resultOutcome === 'WIN'
                  ? 'bg-amber-500 text-slate-950 border-amber-300'
                  : resultOutcome === 'PUSH'
                  ? 'bg-slate-800 text-amber-300 border-amber-500/40'
                  : 'bg-red-950 text-red-200 border-red-500/60'
              }`}
            >
              {resultMessage}
            </div>
          </div>
        )}

        {/* Player Zone */}
        <div className="relative z-10 space-y-1.5 mt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-cinzel font-bold tracking-widest text-amber-300 uppercase">
                Sua Mão
              </span>
              {playerHand.length > 0 && (
                <span className="bg-slate-900/80 border border-amber-500/30 px-1.5 py-0.5 rounded text-[11px] font-mono font-bold text-amber-300">
                  {playerScore.score} {playerScore.isSoft ? '(Suave)' : ''}{' '}
                  {playerScore.isBust ? '(Bust!)' : ''}
                </span>
              )}
            </div>
            {status === 'PLAYER_TURN' && (
              <span className="text-[11px] text-amber-300 font-semibold animate-pulse">
                Sua vez: Peça ou pare
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 min-h-[96px] flex-wrap">
            {playerHand.length === 0 ? (
              <div className="w-16 h-22 rounded border border-dashed border-amber-400/20 flex items-center justify-center text-[10px] text-amber-400/40">
                Jogador
              </div>
            ) : (
              playerHand.map((card, idx) => (
                <PlayingCard key={card.id || idx} card={card} size="sm" />
              ))
            )}
          </div>
        </div>
      </div>

      {/* Controls & Chip Selector Bar */}
      <div className="space-y-2.5">
        {status === 'BETTING' || status === 'ENDED' ? (
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="flex-1">
              <ChipSelector
                currentBet={bet}
                balance={balance}
                onBetChange={setBet}
                disabled={false}
              />
            </div>

            <button
              type="button"
              onClick={startRound}
              disabled={bet <= 0 || bet > balance}
              className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-bold text-sm shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              {status === 'ENDED' ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              <span>{status === 'ENDED' ? 'Nova Rodada' : 'Confirmar e Jogar'}</span>
            </button>
          </div>
        ) : (
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-xl p-2.5 flex flex-wrap items-center justify-center gap-2.5 shadow-lg">
            <button
              type="button"
              onClick={handleHit}
              className="flex-1 min-w-[120px] py-2.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow transition-transform active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Pedir (Hit)</span>
            </button>

            <button
              type="button"
              onClick={() => handleStand()}
              className="flex-1 min-w-[120px] py-2.5 px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs sm:text-sm shadow transition-transform active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Hand className="w-4 h-4" />
              <span>Parar (Stand)</span>
            </button>

            {playerHand.length === 2 && balance >= bet && (
              <button
                type="button"
                onClick={handleDoubleDown}
                className="flex-1 min-w-[120px] py-2.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm shadow transition-transform active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>2x Dobrar</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Rules Modal */}
      <HowToPlayModal
        isOpen={showHowToPlay}
        onClose={() => setShowHowToPlay(false)}
        gameId="blackjack"
      />
    </div>
  );
};
