import React, { useState, useEffect } from 'react';
import { SlotTheme } from '../types/casino';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { ChipSelector } from '../components/ChipSelector';
import { HowToPlayModal } from '../components/HowToPlayModal';
import { ArrowLeft, Play, Sparkles, Shuffle, Flame, HelpCircle } from 'lucide-react';

interface SlotsGameProps {
  balance: number;
  onUpdateBalance: (delta: number, isWin: boolean, gameId: 'slots', betAmount?: number) => void;
  onBackToLobby: () => void;
}

const THEMES: SlotTheme[] = [
  {
    id: 'tigrinho',
    name: 'Tigrinho da Fortuna',
    subtitle: 'Selva Imperial',
    symbols: [
      { icon: '🐯', name: 'Tigre Dourado', multiplier: 50, isJackpot: true },
      { icon: '🐲', name: 'Dragão Imperial', multiplier: 25 },
      { icon: '🐸', name: 'Sapo da Fortuna', multiplier: 15 },
      { icon: '🪙', name: 'Moeda de Ouro', multiplier: 10 },
      { icon: '🐼', name: 'Panda Sagrado', multiplier: 5 },
      { icon: '🎋', name: 'Bambu Verde', multiplier: 3 }
    ]
  },
  {
    id: 'vegas',
    name: 'Vegas 777 Dourado',
    subtitle: 'Frutas Clássicas',
    symbols: [
      { icon: '7️⃣', name: 'Sete da Sorte', multiplier: 50, isJackpot: true },
      { icon: '💎', name: 'Diamante Imperial', multiplier: 25 },
      { icon: '🔔', name: 'Sino Dourado', multiplier: 15 },
      { icon: '🍉', name: 'Melancia', multiplier: 10 },
      { icon: '🍇', name: 'Uva Real', multiplier: 5 },
      { icon: '🍒', name: 'Cereja Dupla', multiplier: 3 }
    ]
  },
  {
    id: 'egypt',
    name: 'Faraó do Nilo',
    subtitle: 'Egito Antigo',
    symbols: [
      { icon: '👑', name: 'Coroa do Faraó', multiplier: 50, isJackpot: true },
      { icon: '👁️', name: 'Olho de Hórus', multiplier: 25 },
      { icon: '🪲', name: 'Escaravelho Sagrado', multiplier: 15 },
      { icon: '🏛️', name: 'Pirâmide de Gizé', multiplier: 10 },
      { icon: '🐺', name: 'Anúbis Protetor', multiplier: 5 },
      { icon: '🏺', name: 'Ânfora Dourada', multiplier: 3 }
    ]
  },
  {
    id: 'space',
    name: 'Odisseia Cósmica',
    subtitle: 'Espaço & Galáxias',
    symbols: [
      { icon: '⭐', name: 'Supernova', multiplier: 50, isJackpot: true },
      { icon: '🚀', name: 'Foguete Hipersônico', multiplier: 25 },
      { icon: '🪐', name: 'Planeta dos Anéis', multiplier: 15 },
      { icon: '🧑‍🚀', name: 'Astronauta', multiplier: 10 },
      { icon: '👽', name: 'Alien Misterioso', multiplier: 5 },
      { icon: '🌀', name: 'Buraco Negro', multiplier: 3 }
    ]
  },
  {
    id: 'ocean',
    name: 'Tesouros do Oceano',
    subtitle: 'Profundezas Abissais',
    symbols: [
      { icon: '📦', name: 'Baú do Tesouro', multiplier: 50, isJackpot: true },
      { icon: '🦈', name: 'Tubarão Predador', multiplier: 25 },
      { icon: '🦪', name: 'Pérola Rara', multiplier: 15 },
      { icon: '🐙', name: 'Polvo Gigante', multiplier: 10 },
      { icon: '🐬', name: 'Golfinho Solar', multiplier: 5 },
      { icon: '🐚', name: 'Concha do Mar', multiplier: 3 }
    ]
  }
];

// 5 Standard Paylines in 3x3:
// 0: top row [0,0], [0,1], [0,2]
// 1: mid row [1,0], [1,1], [1,2]
// 2: bot row [2,0], [2,1], [2,2]
// 3: diag top-left to bot-right [0,0], [1,1], [2,2]
// 4: diag bot-left to top-right [2,0], [1,1], [0,2]
const PAYLINES = [
  { name: 'Linha Superior', coords: [[0, 0], [0, 1], [0, 2]] },
  { name: 'Linha Central', coords: [[1, 0], [1, 1], [1, 2]] },
  { name: 'Linha Inferior', coords: [[2, 0], [2, 1], [2, 2]] },
  { name: 'Diagonal Descendente', coords: [[0, 0], [1, 1], [2, 2]] },
  { name: 'Diagonal Ascendente', coords: [[2, 0], [1, 1], [0, 2]] }
];

export const SlotsGame: React.FC<SlotsGameProps> = ({
  balance,
  onUpdateBalance,
  onBackToLobby
}) => {
  const [bet, setBet] = useState<number>(30);
  const [themeIndex, setThemeIndex] = useState<number>(0);
  const [autoRandomTheme, setAutoRandomTheme] = useState<boolean>(true);
  const [grid, setGrid] = useState<string[][]>([
    ['🐯', '🐲', '🪙'],
    ['🐯', '🐯', '🐯'],
    ['🎋', '🐼', '🐸']
  ]);
  const [spinningReels, setSpinningReels] = useState<boolean[]>([false, false, false]);
  const [winningCells, setWinningCells] = useState<Set<string>>(new Set());
  const [winMessage, setWinMessage] = useState<string>('');
  const [lastWinAmount, setLastWinAmount] = useState<number>(0);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  const currentTheme = THEMES[themeIndex];

  // Helper to pick a random symbol from current theme
  const getRandomSymbol = (theme = currentTheme) => {
    const symbols = theme.symbols;
    // Weighted probabilities: lower multipliers appear more frequently
    const rand = Math.random();
    if (rand < 0.05) return symbols[0].icon; // Jackpot
    if (rand < 0.15) return symbols[1].icon;
    if (rand < 0.30) return symbols[2].icon;
    if (rand < 0.50) return symbols[3].icon;
    if (rand < 0.75) return symbols[4].icon;
    return symbols[5].icon;
  };

  const handleSpin = () => {
    if (spinningReels.some(Boolean) || bet <= 0 || bet > balance) return;

    // Pick new theme if auto-random is on
    let activeTheme = currentTheme;
    if (autoRandomTheme) {
      const nextThemeIdx = Math.floor(Math.random() * THEMES.length);
      setThemeIndex(nextThemeIdx);
      activeTheme = THEMES[nextThemeIdx];
    }

    // Deduct bet
    onUpdateBalance(-bet, false, 'slots');
    setWinMessage('');
    setWinningCells(new Set());
    setLastWinAmount(0);

    // Start all 3 reels spinning
    setSpinningReels([true, true, true]);

    // Fast ticking sound loop
    const tickInterval = setInterval(() => {
      soundManager.playReelTick();
    }, 90);

    // Prepare final grid
    const targetGrid: string[][] = [
      [getRandomSymbol(activeTheme), getRandomSymbol(activeTheme), getRandomSymbol(activeTheme)],
      [getRandomSymbol(activeTheme), getRandomSymbol(activeTheme), getRandomSymbol(activeTheme)],
      [getRandomSymbol(activeTheme), getRandomSymbol(activeTheme), getRandomSymbol(activeTheme)]
    ];

    // Sequential stop:
    // Reel 0 stops at 900ms
    setTimeout(() => {
      setSpinningReels([false, true, true]);
      soundManager.playReelStop();
      setGrid((prev) => [
        [targetGrid[0][0], prev[0][1], prev[0][2]],
        [targetGrid[1][0], prev[1][1], prev[1][2]],
        [targetGrid[2][0], prev[2][1], prev[2][2]]
      ]);
    }, 900);

    // Reel 1 stops at 1500ms
    setTimeout(() => {
      setSpinningReels([false, false, true]);
      soundManager.playReelStop();
      setGrid((prev) => [
        [targetGrid[0][0], targetGrid[0][1], prev[0][2]],
        [targetGrid[1][0], targetGrid[1][1], prev[1][2]],
        [targetGrid[2][0], targetGrid[2][1], prev[2][2]]
      ]);
    }, 1500);

    // Reel 2 stops at 2100ms
    setTimeout(() => {
      clearInterval(tickInterval);
      setSpinningReels([false, false, false]);
      soundManager.playReelStop();
      setGrid(targetGrid);

      // Evaluate Paylines
      let totalMultiplier = 0;
      const hitCells = new Set<string>();
      const hitLines: string[] = [];

      for (const line of PAYLINES) {
        const s1 = targetGrid[line.coords[0][0]][line.coords[0][1]];
        const s2 = targetGrid[line.coords[1][0]][line.coords[1][1]];
        const s3 = targetGrid[line.coords[2][0]][line.coords[2][1]];

        if (s1 === s2 && s2 === s3) {
          const symConfig = activeTheme.symbols.find((s) => s.icon === s1);
          const mult = symConfig ? symConfig.multiplier : 3;
          totalMultiplier += mult;
          hitLines.push(`${line.name} (${s1} ${mult}x)`);

          line.coords.forEach(([r, c]) => {
            hitCells.add(`${r}-${c}`);
          });
        }
      }

      setWinningCells(hitCells);

      if (totalMultiplier > 0) {
        const totalWon = Math.floor(bet * totalMultiplier);
        setLastWinAmount(totalWon);

        if (totalMultiplier >= 50) {
          soundManager.playJackpot();
          fireConfetti(3500);
          setWinMessage(`GRANDE JACKPOT! +${totalWon} fichas (${totalMultiplier}x)!`);
        } else {
          soundManager.playWin();
          fireConfetti(2000);
          setWinMessage(`VITÓRIA! ${hitLines.join(', ')}: +${totalWon} fichas!`);
        }

        onUpdateBalance(totalWon, true, 'slots', bet);
      } else {
        soundManager.playLoss();
        setWinMessage('Não foi dessa vez. Tente novamente!');
      }
    }, 2100);
  };

  const isSpinning = spinningReels.some(Boolean);

  return (
    <div className="space-y-3 max-w-3xl mx-auto animate-fade-in">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Voltar ao Lobby</span>
        </button>

        {/* Theme indicator and toggle */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={isSpinning}
            onClick={() => {
              soundManager.playClick();
              setThemeIndex((prev) => (prev + 1) % THEMES.length);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>Tema: {currentTheme.name}</span>
          </button>

          <button
            onClick={() => setShowHowToPlay(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Como Jogar</span>
          </button>
        </div>
      </div>

      {/* Slot Machine Cabinet Design */}
      <div className="relative rounded-2xl border-2 sm:border-4 border-amber-600 bg-gradient-to-b from-[#1c0f06] via-[#2a1708] to-[#120803] p-3 sm:p-5 shadow-2xl overflow-hidden">
        {/* Ornate Gold Crown Header */}
        <div className="text-center pb-2 border-b border-amber-500/30 flex flex-col items-center">
          <div className="flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
            <h2 className="font-cinzel text-base sm:text-xl font-black text-gold-gradient tracking-wider uppercase">
              {currentTheme.name}
            </h2>
            <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
          </div>
          <span className="text-[10px] text-amber-400/80 uppercase tracking-widest">
            {currentTheme.subtitle} · 5 Linhas de Pagamento
          </span>
        </div>

        {/* 3x3 Reels Window */}
        <div className="my-3 bg-slate-950/90 rounded-xl border-2 sm:border-4 border-amber-500/40 p-2 sm:p-3 shadow-inner relative">
          <div className="grid grid-cols-3 gap-2 sm:gap-3 max-w-sm mx-auto">
            {[0, 1, 2].map((colIdx) => {
              const reelSpinning = spinningReels[colIdx];
              return (
                <div
                  key={colIdx}
                  className={`bg-[#0d1612] border border-amber-500/30 rounded-lg p-1.5 flex flex-col items-center justify-around h-36 sm:h-48 shadow-md overflow-hidden ${
                    reelSpinning ? 'reel-spinning' : ''
                  }`}
                >
                  {[0, 1, 2].map((rowIdx) => {
                    const isWinning = winningCells.has(`${rowIdx}-${colIdx}`);
                    const symbol = grid[rowIdx][colIdx];
                    return (
                      <div
                        key={rowIdx}
                        className={`w-full py-1 flex items-center justify-center rounded text-2xl sm:text-3xl select-none transition-all duration-300 ${
                          isWinning
                            ? 'bg-amber-400/30 ring-2 ring-amber-300 scale-105 animate-pulse'
                            : ''
                        }`}
                      >
                        {symbol}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>

        {/* Win Alert / Message Banner */}
        <div className="min-h-[36px] flex items-center justify-center text-center">
          {winMessage ? (
            <div
              className={`inline-block px-4 py-1.5 rounded-lg font-cinzel font-bold text-xs sm:text-sm border shadow-lg ${
                lastWinAmount > 0
                  ? 'bg-amber-500 text-slate-950 border-amber-300 animate-bounce'
                  : 'bg-slate-900 border-slate-700 text-slate-300'
              }`}
            >
              {winMessage}
            </div>
          ) : (
            <span className="text-[11px] text-amber-300/70">
              Combine 3 símbolos iguais em qualquer uma das 5 linhas
            </span>
          )}
        </div>

        {/* Theme Symbol Multiplier Strip */}
        <div className="mt-2 pt-2 border-t border-amber-500/20 flex items-center justify-around flex-wrap gap-1.5 text-[11px]">
          {currentTheme.symbols.map((sym) => (
            <div
              key={sym.name}
              className="flex items-center gap-1 bg-slate-900/80 px-1.5 py-0.5 rounded border border-amber-500/20"
            >
              <span className="text-sm">{sym.icon}</span>
              <span className="font-mono text-amber-300 font-bold">{sym.multiplier}x</span>
            </div>
          ))}
        </div>
      </div>

      {/* Betting Controls & Spin Action in a single row */}
      <div className="bg-[#09150f] border border-amber-500/30 rounded-xl p-2.5 sm:p-3 shadow-xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        <div className="flex-1">
          <ChipSelector
            currentBet={bet}
            balance={balance}
            onBetChange={setBet}
            disabled={isSpinning}
          />
        </div>

        <button
          type="button"
          disabled={isSpinning || bet <= 0 || bet > balance}
          onClick={handleSpin}
          className="sm:w-56 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-black text-xs sm:text-sm shadow-xl shadow-amber-500/30 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>{isSpinning ? 'Rodando...' : 'Girar Bobinas'}</span>
        </button>
      </div>

      {/* Rules Modal */}
      <HowToPlayModal
        isOpen={showHowToPlay}
        onClose={() => setShowHowToPlay(false)}
        gameId="slots"
      />
    </div>
  );
};
