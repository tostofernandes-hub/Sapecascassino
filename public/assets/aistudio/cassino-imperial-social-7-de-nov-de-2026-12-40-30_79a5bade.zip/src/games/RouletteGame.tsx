import React, { useState, useRef } from 'react';
import { soundManager } from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { HowToPlayModal } from '../components/HowToPlayModal';
import { ArrowLeft, Play, RotateCcw, Sparkles, HelpCircle } from 'lucide-react';

interface RouletteGameProps {
  balance: number;
  onUpdateBalance: (delta: number, isWin: boolean, gameId: 'roulette', betAmount?: number) => void;
  onBackToLobby: () => void;
}

// European Roulette Wheel sequence
const WHEEL_NUMBERS = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10,
  5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
];

const RED_NUMBERS = new Set([
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36
]);

function getNumberColor(num: number): 'green' | 'red' | 'black' {
  if (num === 0) return 'green';
  return RED_NUMBERS.has(num) ? 'red' : 'black';
}

type BetType = 
  | { kind: 'single'; number: number }
  | { kind: 'color'; color: 'red' | 'black' }
  | { kind: 'parity'; parity: 'even' | 'odd' }
  | { kind: 'range'; range: 'low' | 'high' }
  | { kind: 'dozen'; dozen: 1 | 2 | 3 };

interface PlacedBet {
  id: string;
  type: BetType;
  label: string;
  amount: number;
  multiplier: number; // e.g. 35 for single (payout 35:1 + original = 36x)
}

export const RouletteGame: React.FC<RouletteGameProps> = ({
  balance,
  onUpdateBalance,
  onBackToLobby
}) => {
  const [selectedChip, setSelectedChip] = useState<number>(25);
  const [bets, setBets] = useState<PlacedBet[]>([]);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [winningNumber, setWinningNumber] = useState<number | null>(null);
  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [history, setHistory] = useState<number[]>([14, 2, 31, 0, 7]);
  const [lastWinSummary, setLastWinSummary] = useState<{ won: boolean; totalWon: number; text: string } | null>(null);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  const totalBetAmount = bets.reduce((sum, b) => sum + b.amount, 0);

  // Add or increment a bet
  const handlePlaceBet = (type: BetType, label: string, multiplier: number) => {
    if (isSpinning) return;
    if (totalBetAmount + selectedChip > balance) return;

    soundManager.playChip();

    setBets((prev) => {
      const existingIdx = prev.findIndex((b) => JSON.stringify(b.type) === JSON.stringify(type));
      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx].amount += selectedChip;
        return copy;
      } else {
        return [
          ...prev,
          {
            id: `${Date.now()}-${Math.random()}`,
            type,
            label,
            amount: selectedChip,
            multiplier
          }
        ];
      }
    });
  };

  const clearBets = () => {
    if (isSpinning) return;
    soundManager.playClick();
    setBets([]);
  };

  // Spin the wheel
  const handleSpin = () => {
    if (isSpinning || bets.length === 0 || totalBetAmount > balance) return;

    setIsSpinning(true);
    setLastWinSummary(null);

    // Deduct total bet
    onUpdateBalance(-totalBetAmount, false, 'roulette');

    // Pick random winning number
    const drawnNumber = Math.floor(Math.random() * 37); // 0 to 36
    const numberIndex = WHEEL_NUMBERS.indexOf(drawnNumber);
    const sliceAngle = 360 / WHEEL_NUMBERS.length; // ~9.7297 deg

    // Realistic physics: 5 to 7 full revolutions plus target offset
    const currentRot = wheelRotation % 360;
    const extraRotations = (5 + Math.floor(Math.random() * 2)) * 360;
    // We want the drawn number to land at the top pointer (0 deg)
    const targetAngle = extraRotations + (360 - numberIndex * sliceAngle);
    const finalRot = wheelRotation + (targetAngle - currentRot);

    setWheelRotation(finalRot);

    // Play ticking audio sequence
    let tickCount = 0;
    const maxTicks = 24;
    const tickInterval = setInterval(() => {
      tickCount++;
      soundManager.playRouletteTick(800 + tickCount * 30);
      if (tickCount >= maxTicks) {
        clearInterval(tickInterval);
      }
    }, 140);

    // After animation finishes (~4 seconds)
    setTimeout(() => {
      setIsSpinning(false);
      setWinningNumber(drawnNumber);
      setHistory((prev) => [drawnNumber, ...prev.slice(0, 9)]);

      // Calculate payouts
      let totalWon = 0;
      const winningBets: string[] = [];

      for (const b of bets) {
        let isHit = false;

        switch (b.type.kind) {
          case 'single':
            if (b.type.number === drawnNumber) isHit = true;
            break;
          case 'color':
            if (drawnNumber !== 0 && getNumberColor(drawnNumber) === b.type.color) isHit = true;
            break;
          case 'parity':
            if (drawnNumber !== 0) {
              const isEven = drawnNumber % 2 === 0;
              if (b.type.parity === 'even' && isEven) isHit = true;
              if (b.type.parity === 'odd' && !isEven) isHit = true;
            }
            break;
          case 'range':
            if (drawnNumber !== 0) {
              if (b.type.range === 'low' && drawnNumber >= 1 && drawnNumber <= 18) isHit = true;
              if (b.type.range === 'high' && drawnNumber >= 19 && drawnNumber <= 36) isHit = true;
            }
            break;
          case 'dozen':
            if (drawnNumber !== 0) {
              if (b.type.dozen === 1 && drawnNumber >= 1 && drawnNumber <= 12) isHit = true;
              if (b.type.dozen === 2 && drawnNumber >= 13 && drawnNumber <= 24) isHit = true;
              if (b.type.dozen === 3 && drawnNumber >= 25 && drawnNumber <= 36) isHit = true;
            }
            break;
        }

        if (isHit) {
          // Payout is original bet + multiplier * bet
          const winAmount = b.amount + b.amount * b.multiplier;
          totalWon += winAmount;
          winningBets.push(`${b.label} (+${winAmount})`);
        }
      }

      if (totalWon > 0) {
        soundManager.playWin();
        fireConfetti(2500);
        onUpdateBalance(totalWon, true, 'roulette', totalBetAmount);
        setLastWinSummary({
          won: true,
          totalWon,
          text: `Número ${drawnNumber} (${getNumberColor(drawnNumber) === 'red' ? 'Vermelho' : drawnNumber === 0 ? 'Verde' : 'Preto'})! Você ganhou ${totalWon} fichas!`
        });
      } else {
        soundManager.playLoss();
        setLastWinSummary({
          won: false,
          totalWon: 0,
          text: `Número sorteado: ${drawnNumber} (${getNumberColor(drawnNumber) === 'red' ? 'Vermelho' : drawnNumber === 0 ? 'Verde' : 'Preto'}). Nenhuma aposta premiada.`
        });
      }
    }, 4200);
  };

  return (
    <div className="space-y-3 max-w-6xl mx-auto animate-fade-in">
      {/* Top Bar Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToLobby}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-amber-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Voltar ao Lobby</span>
        </button>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* History of last drawn numbers */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-slate-400 hidden sm:inline">Últimos:</span>
            <div className="flex items-center gap-1">
              {history.map((num, idx) => {
                const color = getNumberColor(num);
                return (
                  <span
                    key={idx}
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shadow-sm ${
                      color === 'red' ? 'bg-red-600' : color === 'green' ? 'bg-emerald-600' : 'bg-slate-900 border border-slate-700'
                    }`}
                  >
                    {num}
                  </span>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => setShowHowToPlay(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-amber-500/30 text-xs font-semibold text-amber-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Como Jogar</span>
          </button>
        </div>
      </div>

      {/* Main Roulette Table & Wheel Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4 items-start">
        {/* Left: Wheel Animation */}
        <div className="lg:col-span-4 bg-[#09150f] border border-amber-500/20 rounded-xl p-3 sm:p-4 flex flex-col items-center justify-center shadow-xl">
          <div className="relative w-40 h-40 sm:w-48 sm:h-48 flex items-center justify-center">
            {/* Top Ball Indicator Needle */}
            <div className="absolute -top-2 z-30 flex flex-col items-center">
              <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[11px] border-t-amber-400 drop-shadow-md" />
            </div>

            {/* Rotating Wheel SVG */}
            <div
              className="w-full h-full rounded-full transition-transform ease-out shadow-2xl overflow-hidden border-2 sm:border-4 border-amber-600"
              style={{
                transform: `rotate(${wheelRotation}deg)`,
                transitionDuration: isSpinning ? '4.2s' : '0s',
                transitionTimingFunction: 'cubic-bezier(0.15, 0.9, 0.2, 1)'
              }}
            >
              <svg viewBox="0 0 200 200" className="w-full h-full select-none">
                <circle cx="100" cy="100" r="98" fill="#1e140d" stroke="#d97706" strokeWidth="2" />
                {WHEEL_NUMBERS.map((num, i) => {
                  const angle = (360 / WHEEL_NUMBERS.length) * i;
                  const color = getNumberColor(num);
                  const fillColor = color === 'green' ? '#059669' : color === 'red' ? '#dc2626' : '#0f172a';
                  return (
                    <g key={num} transform={`rotate(${angle} 100 100)`}>
                      <path
                        d="M 100 100 L 91.5 5 A 95 95 0 0 1 108.5 5 Z"
                        fill={fillColor}
                        stroke="#78350f"
                        strokeWidth="0.5"
                      />
                      <text
                        x="100"
                        y="22"
                        fill="#ffffff"
                        fontSize="6.5"
                        fontWeight="bold"
                        textAnchor="middle"
                        transform={`rotate(${90} 100 22)`}
                      >
                        {num}
                      </text>
                    </g>
                  );
                })}
                {/* Center Brass Hub */}
                <circle cx="100" cy="100" r="32" fill="#291a10" stroke="#f59e0b" strokeWidth="2" />
                <circle cx="100" cy="100" r="14" fill="#d97706" />
                <circle cx="100" cy="100" r="6" fill="#fef08a" />
              </svg>
            </div>
          </div>

          {/* Outcome Indicator */}
          <div className="mt-2 text-center">
            {winningNumber !== null ? (
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest">
                  Número Sorteado
                </span>
                <div className="flex items-center justify-center gap-2">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center font-cinzel text-lg font-black text-white shadow-md ${
                      getNumberColor(winningNumber) === 'red'
                        ? 'bg-red-600'
                        : winningNumber === 0
                        ? 'bg-emerald-600'
                        : 'bg-slate-900 border border-slate-700'
                    }`}
                  >
                    {winningNumber}
                  </div>
                  <div className="text-left text-[11px] leading-tight">
                    <div className="font-bold text-white capitalize">
                      {getNumberColor(winningNumber) === 'red'
                        ? 'Vermelho'
                        : winningNumber === 0
                        ? 'Zero (Verde)'
                        : 'Preto'}
                    </div>
                    <div className="text-slate-400">
                      {winningNumber !== 0 && (winningNumber % 2 === 0 ? 'Par' : 'Ímpar')}{' '}
                      {winningNumber !== 0 && (winningNumber <= 18 ? '· Baixo' : '· Alto')}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <span className="text-[11px] text-slate-400">
                Escolha as apostas na mesa e gire
              </span>
            )}
          </div>
        </div>

        {/* Right: Betting Grid & Table Felt */}
        <div className="lg:col-span-8 space-y-2.5">
          <div className="casino-felt border border-amber-500/30 rounded-xl p-2.5 sm:p-3.5 shadow-xl">
            <div className="text-[11px] text-amber-300 font-cinzel font-bold uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Mesa de Apostas Europeia</span>
              <span className="text-slate-400 normal-case font-sans">
                Ficha ativa: <strong className="text-amber-400">{selectedChip}</strong>
              </span>
            </div>

            {/* 0 and Numbers 1-36 grid */}
            <div className="space-y-1.5">
              {/* Row 0 */}
              <button
                type="button"
                disabled={isSpinning}
                onClick={() => handlePlaceBet({ kind: 'single', number: 0 }, 'Número 0', 35)}
                className="w-full py-1.5 bg-emerald-700 hover:bg-emerald-600 border border-emerald-400/40 rounded-md text-white font-bold text-xs shadow transition-colors flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>0 (Zero Pleno - Paga 35:1)</span>
              </button>

              {/* Numbers Grid (1-36) */}
              <div className="grid grid-cols-6 sm:grid-cols-12 gap-1">
                {Array.from({ length: 36 }, (_, i) => i + 1).map((num) => {
                  const color = getNumberColor(num);
                  const activeBet = bets.find(
                    (b) => b.type.kind === 'single' && b.type.number === num
                  );
                  return (
                    <button
                      key={num}
                      type="button"
                      disabled={isSpinning}
                      onClick={() =>
                        handlePlaceBet({ kind: 'single', number: num }, `Número ${num}`, 35)
                      }
                      className={`relative h-7 sm:h-8 rounded font-bold text-[11px] sm:text-xs text-white flex items-center justify-center shadow transition-all cursor-pointer ${
                        color === 'red' ? 'bg-red-600 hover:bg-red-500' : 'bg-slate-900 hover:bg-slate-800 border border-slate-700'
                      } ${activeBet ? 'ring-2 ring-amber-300 scale-95' : ''}`}
                    >
                      {num}
                      {activeBet && (
                        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-400 text-slate-950 text-[8px] font-black flex items-center justify-center shadow">
                          {activeBet.amount}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Outside Bets: Dúzias (1-12, 13-24, 25-36) */}
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                {[1, 2, 3].map((d) => {
                  const label = d === 1 ? '1ª Dúzia (1-12)' : d === 2 ? '2ª Dúzia (13-24)' : '3ª Dúzia (25-36)';
                  const activeBet = bets.find((b) => b.type.kind === 'dozen' && b.type.dozen === d);
                  return (
                    <button
                      key={d}
                      type="button"
                      disabled={isSpinning}
                      onClick={() => handlePlaceBet({ kind: 'dozen', dozen: d as 1 | 2 | 3 }, label, 2)}
                      className={`relative py-1.5 px-1 rounded-md bg-slate-900/90 border border-slate-700 hover:border-amber-400 text-[11px] font-semibold text-slate-200 transition-colors cursor-pointer ${
                        activeBet ? 'ring-2 ring-amber-400 bg-amber-950/40' : ''
                      }`}
                    >
                      <span>{label}</span>
                      <span className="text-[10px] text-amber-400 font-mono ml-1">2:1</span>
                      {activeBet && (
                        <span className="absolute -top-1 -right-1 px-1 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[8px] font-black">
                          {activeBet.amount}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Outside Bets: Cores, Par/Ímpar, Baixo/Alto (1:1) */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 pt-1">
                {/* Red */}
                <button
                  type="button"
                  disabled={isSpinning}
                  onClick={() => handlePlaceBet({ kind: 'color', color: 'red' }, 'Vermelho', 1)}
                  className="py-1.5 rounded-md bg-red-700 hover:bg-red-600 text-white font-bold text-[11px] shadow flex items-center justify-center transition-colors cursor-pointer"
                >
                  Vermelho 1:1
                </button>

                {/* Black */}
                <button
                  type="button"
                  disabled={isSpinning}
                  onClick={() => handlePlaceBet({ kind: 'color', color: 'black' }, 'Preto', 1)}
                  className="py-1.5 rounded-md bg-slate-950 hover:bg-slate-900 border border-slate-700 text-white font-bold text-[11px] shadow flex items-center justify-center transition-colors cursor-pointer"
                >
                  Preto 1:1
                </button>

                {/* Par / Ímpar */}
                <button
                  type="button"
                  disabled={isSpinning}
                  onClick={() => handlePlaceBet({ kind: 'parity', parity: 'even' }, 'Par (Even)', 1)}
                  className="py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] transition-colors cursor-pointer"
                >
                  Par 1:1
                </button>

                <button
                  type="button"
                  disabled={isSpinning}
                  onClick={() => handlePlaceBet({ kind: 'parity', parity: 'odd' }, 'Ímpar (Odd)', 1)}
                  className="py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] transition-colors cursor-pointer"
                >
                  Ímpar 1:1
                </button>

                {/* 1-18 / 19-36 */}
                <button
                  type="button"
                  disabled={isSpinning}
                  onClick={() => handlePlaceBet({ kind: 'range', range: 'low' }, 'Baixo (1-18)', 1)}
                  className="py-1.5 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] cursor-pointer"
                >
                  1 a 18 (1:1)
                </button>

                <button
                  type="button"
                  disabled={isSpinning}
                  onClick={() => handlePlaceBet({ kind: 'range', range: 'high' }, 'Alto (19-36)', 1)}
                  className="py-1.5 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] cursor-pointer"
                >
                  19 a 36 (1:1)
                </button>
              </div>
            </div>
          </div>

          {/* Result Alert / Feedback */}
          {lastWinSummary && (
            <div
              className={`p-2 rounded-lg border text-center font-bold text-xs ${
                lastWinSummary.won
                  ? 'bg-amber-950/40 border-amber-500/60 text-amber-300'
                  : 'bg-slate-900 border-slate-700 text-slate-300'
              }`}
            >
              {lastWinSummary.text}
            </div>
          )}

          {/* Chips Selector & Spin Action in unified single row */}
          <div className="bg-slate-900/95 border border-amber-500/30 rounded-xl p-2.5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            {/* Value selector */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400 font-semibold mr-1">Ficha:</span>
              {[10, 25, 50, 100, 500].map((val) => (
                <button
                  key={val}
                  type="button"
                  disabled={isSpinning}
                  onClick={() => {
                    soundManager.playClick();
                    setSelectedChip(val);
                  }}
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full text-[11px] font-bold transition-all cursor-pointer ${
                    selectedChip === val
                      ? 'bg-amber-500 text-slate-950 scale-105 shadow-md ring-2 ring-white font-black'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {val}
                </button>
              ))}
            </div>

            {/* Total bet & clear */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isSpinning || bets.length === 0}
                onClick={clearBets}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-semibold text-slate-300 disabled:opacity-40 cursor-pointer"
              >
                Limpar
              </button>

              <div className="text-right">
                <span className="text-[9px] text-slate-400 block uppercase leading-none">Aposta</span>
                <span className="font-mono text-xs sm:text-sm font-bold text-amber-300 tabular-nums leading-tight">
                  {totalBetAmount} fichas
                </span>
              </div>

              {/* Action Spin Button */}
              <button
                type="button"
                disabled={isSpinning || bets.length === 0 || totalBetAmount > balance}
                onClick={handleSpin}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-cinzel font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ml-1"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{isSpinning ? 'Girando...' : 'Girar Roleta'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Rules Modal */}
      <HowToPlayModal
        isOpen={showHowToPlay}
        onClose={() => setShowHowToPlay(false)}
        gameId="roulette"
      />
    </div>
  );
};
