export type GameId = 
  | 'lobby'
  | 'blackjack'
  | 'roulette'
  | 'texas-holdem'
  | 'video-poker'
  | 'baccarat'
  | 'slots'
  | 'lottery'
  | 'records';

export type Suit = 'hearts' | 'diamonds' | 'clubs' | 'spades';

export interface Card {
  id: string;
  suit: Suit;
  value: number; // 1 (Ace) to 13 (King)
  label: string; // 'A', '2'-'10', 'J', 'Q', 'K'
}

export interface PlayerStats {
  chips: number;
  highestBalance: number;
  biggestWin: number;
  currentStreak: number;
  longestStreak: number;
  recordDate: string;
  lastDailyBonusDate: string;
  dailyLoginStreak: number;
  gameWins: {
    blackjack: number;
    roulette: number;
    'texas-holdem': number;
    'video-poker': number;
    baccarat: number;
    slots: number;
    lottery: number;
  };
  totalRounds: number;
}

export type PokerHandRank =
  | 'ROYAL_FLUSH'
  | 'STRAIGHT_FLUSH'
  | 'FOUR_OF_A_KIND'
  | 'FULL_HOUSE'
  | 'FLUSH'
  | 'STRAIGHT'
  | 'THREE_OF_A_KIND'
  | 'TWO_PAIR'
  | 'JACKS_OR_BETTER'
  | 'HIGH_CARD';

export interface PokerHandResult {
  rank: PokerHandRank;
  name: string;
  payoutMultiplier: number;
  description: string;
}

export interface SlotTheme {
  id: string;
  name: string;
  subtitle: string;
  symbols: {
    icon: string;
    name: string;
    multiplier: number; // For 3 in a line
    isWild?: boolean;
    isJackpot?: boolean;
  }[];
}
